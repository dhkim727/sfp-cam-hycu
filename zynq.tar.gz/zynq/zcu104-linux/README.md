# zcu104-linux

시스템 1 송신부(ZCU104)용 SD 카드 이미지 빌드 묶음. `zcu104_linux_plan.md`의 권장 경로(A → B)를 따른다.

```
hw/*.xsa ─┬─▶ system.bit.bin (bootgen)
          └─▶ pl.dtbo (DTG 오버레이 + generic-uio 패치)
base/공식 Ubuntu 22.04 이미지 ─▶ 루트 파일 시스템에 위 파일 + pl-load 서비스 주입 ─▶ out/sdcard.img
```

- 공식 이미지의 부트 자산(BOOT.BIN = ImgSel, 부트 스크립트, DTB)은 **건드리지 않는다**. PL은 부팅 후 configfs 오버레이로 올린다.
- 문제가 생기면 PL 자동 로드만 끄면 공식 이미지 그대로 부팅한다 (아래 5장).
- 자체 빌드 경로(계획서 D단계: PetaLinux/Ubuntu 24.04)와 xlnx-config PAC(C단계)는 이 묶음에 들어 있지 않다.

---

## 1. 빠른 시작

```bash
chmod +x build.sh                       # 복사 과정에서 실행 권한이 빠졌을 수 있음 ('bash build.sh'·'make'는 그대로 됨)

# 1) 공식 이미지: ubuntu.com/download/amd → Zynq UltraScale+ MPSoC 개발 보드용 Ubuntu Desktop 22.04 LTS
cp ~/Downloads/iot-*-zcu-*2204*.img.xz base/

# 2) XSA (Vivado: Export Hardware > Include bitstream)
cp ~/vivado/zcu104/zcu104_tx_wrapper.xsa hw/

# 3) config.env의 UIO_NODES를 설계의 IP 인스턴스 이름에 맞춘다 (기본: axi_dma_0 link_ctrl_0 tx_test_gen_0)

# 4) 빌드 → SD 카드
./build.sh
sudo dd if=out/sdcard.img of=/dev/sdX bs=4M conv=fsync status=progress
```

보드(SW6: 1번 ON, 2·3·4 OFF = SD 부트)에서 첫 부팅 후 (계획서 3.2):

```bash
# 로그인 ubuntu / ubuntu (비밀번호 변경 요구)
sudo apt update && sudo apt upgrade
sudo snap install xlnx-config --classic --channel=2.x && xlnx-config.sysinit
sudo udmabuf-install          # u-dma-buf 커널 모듈 빌드·설치 (인터넷 필요, 커널이 바뀌면 다시)
sudo pl-load restart          # 또는 재부팅
pl-load status                # fpga0 operating, overlay applied, /dev/uio*, /dev/udmabuf0, CMA
```

## 2. 빌드 호스트 준비

```bash
sudo apt install git unzip device-tree-compiler e2fsprogs fdisk xz-utils
```

- `device-tree-compiler`: dtc, fdtget, fdtput / `e2fsprogs`: debugfs, dumpe2fs, e2fsck / `fdisk`: sfdisk
- Vitis 2025.2: `xsct`(DTG) 또는 `sdtgen`, 그리고 `bootgen`. settings64.sh는 자동으로 찾고, 다른 곳이면 `config.local.env`에
  `XILINX_SETTINGS=/경로/settings64.sh`.
- root 권한이 필요 없다. 이미지 안의 파일은 debugfs로 직접 쓴다 (루프 마운트 없음).
- 디스크: 공식 이미지를 풀어 둔 `build/image/base.img`(재사용 캐시)와 `out/sdcard.img`가 각각 이미지 크기만큼 필요하다 (sparse 파일).

## 3. build.sh

```
./build.sh [all|fetch|hw|dt|bit|bundle|image] [--clean] [--xsa 파일] [--base 이미지]
./build.sh status | clean | distclean
```

| 단계 | 입력 | 출력 | 다시 도는 조건 |
|---|---|---|---|
| fetch | `DTG_TAG` | `src/device-tree-xlnx` | 최초 1회, 태그 변경 (DT_GEN=dtg일 때만) |
| hw | XSA | `build/hw/system.bit` | XSA 내용(sha256) 변경 |
| dt | hw | `out/pl.dtbo`, `out/pl.dts`(확인용) | hw·UIO_NODES·FW_NAME·DT_GEN 변경 |
| bit | hw | `out/system.bit.bin` | hw 변경 |
| bundle | dt, bit, `board/overlay/` | `out/pl-update.tar.gz` | 위 입력·PL_NAME·UDMABUF 설정 변경 |
| image | bundle, 공식 이미지 | `out/sdcard.img` | bundle·베이스 이미지·PL_AUTOLOAD·TEXT_MODE_BOOT 변경 |

- 공식 이미지가 없어도 `./build.sh bundle`까지는 된다.
- 단계별 로그: `build/logs/<단계>.log`, 주입 명령과 결과: `build/image/inject.cmds`, `inject.log`, `e2fsck.log`.

### 이미 설치된 보드에 PL만 바꿔 넣기 (다시 굽지 않음)

```bash
./build.sh bundle
scp out/pl-update.tar.gz ubuntu@<보드>:
ssh ubuntu@<보드> 'sudo tar -C / --keep-directory-symlink -xzf pl-update.tar.gz && sudo systemctl daemon-reload && sudo systemctl enable pl-load && sudo pl-load restart'
```

## 4. 보드에 들어가는 것

| 경로 | 내용 |
|---|---|
| `/lib/firmware/system.bit.bin` | `bootgen -arch zynqmp -process_bitstream bin` 결과 (FPGA Manager 형식) |
| `/lib/firmware/sys1.dtbo` | PL 오버레이. UIO_NODES 노드는 `compatible = "generic-uio"`, `firmware-name = "system.bit.bin"` |
| `/etc/pl-load.conf` | PL_NAME, 파일 이름, u-dma-buf 크기·버전 (config.env에서 생성) |
| `/usr/local/sbin/pl-load` | `start / stop / restart / status` — 계획서 4.4의 configfs 절차 + uio + u-dma-buf |
| `/etc/systemd/system/pl-load.service` | 부팅 때 `pl-load start` (`PL_AUTOLOAD=1`이면 켜 둠) |
| `/etc/modprobe.d/uio-generic.conf` | `options uio_pdrv_genirq of_id=generic-uio` |
| `/usr/local/sbin/udmabuf-install` | 계획서 4.5의 u-dma-buf 빌드·설치 (`UDMABUF_TAG`) |
| `default.target` | `TEXT_MODE_BOOT=1`이면 multi-user.target (계획서 3.2-7) |

## 5. 안전장치

- **PL 자동 로드 끄기**: PC에서 SD 카드의 FAT 파티션(system-boot)에 빈 파일 `pl-noload`를 만들면 pl-load.service가 건너뛴다.
  또는 `config.env`의 `PL_AUTOLOAD=0`으로 다시 빌드.
- 이미지 단계는 루트 파일 시스템에 파일 7개와 링크 2개만 더한다. 부트 파티션은 바이트 단위로 원본과 같다.
- 주입 후 넣은 파일을 다시 꺼내 내용·권한을 비교하고, `e2fsck -fn`으로 파일 시스템을 검사한다.

## 6. 계획서와 다른 점 / 확인해서 보완한 점

| 항목 | 내용 |
|---|---|
| bootgen 명령 | 계획서 4.2의 `bootgen -image bit.bif -arch zynqmp -o system.bit.bin -w`는 부트 헤더가 붙은 **부트 이미지**를 만든다 (bootgen 2025.2 소스로 빌드해 확인). FPGA Manager용 원시 비트스트림은 `-process_bitstream bin`으로 만든다. |
| pl.dtsi 수정 | 텍스트를 직접 고치는 대신 dtc로 컴파일한 dtbo의 해당 노드를 `fdtput`으로 바꾼다 (`__symbols__`로 레이블 → 경로). 레이블이 없으면 오버레이의 레이블 목록과 함께 멈춘다. |
| PL 클럭 확인 | 오버레이의 `xlnx,fclk` 노드 주파수를 `PL_CLK0_HZ`(150 MHz)와 비교해 1% 넘게 다르면 경고한다. |
| 오버레이 이름 | `/lib/firmware/<PL_NAME>.dtbo` (기본 sys1.dtbo). configfs 디렉터리 이름도 PL_NAME. |

## 7. 보드에서 처음 확인할 것 (계획서 4.3)

`pl-load start`가 아래를 먼저 검사하고, 안 되면 이유를 출력한다.

```bash
ls /sys/class/fpga_manager/                  # fpga0
ls /sys/kernel/config/device-tree/overlays   # configfs 오버레이 인터페이스 — 없으면 C단계(PAC)로
ls /proc/device-tree/__symbols__ | head      # 없으면 오버레이 레이블을 target-path로 바꿔야 함
```

- CMA 부족 시(계획서 4.6): `/etc/default/flash-kernel`의 `LINUX_KERNEL_CMDLINE`에 `cma=1100M` → `sudo flash-kernel` → 재부팅.
- PL IP가 응답하지 않으면 pl_resetn0 해제 상태를 확인한다 (계획서 4.7).

## 8. 시험한 범위

클라우드 환경에서 가짜 XSA·가짜 공식 이미지(FAT `system-boot` + ext4 `writable`, /lib → usr/lib)로 전 단계를 돌렸다.
bootgen은 2025.2 소스로 빌드한 것을 썼다.

- dt: DTG 오버레이 형식 pl.dtsi → dtbo, generic-uio·firmware-name 패치, PL 클럭 확인, 잘못된 레이블 오류
- image: 루트 파티션 자동 탐지('writable'), 파일 소유자 0:0·권한, 서비스·default.target 링크, e2fsck 통과, 부트 파티션 무변경
- 변경 감지: XSA 변경 → hw → dt·bit → bundle → image

확인하지 못한 것: 실제 xsct/sdtgen 실행, 실제 공식 이미지(루트 파티션 레이블은 'writable'로 예상, 다르면 `ROOT_PART=`), 보드에서의 오버레이 적용.
