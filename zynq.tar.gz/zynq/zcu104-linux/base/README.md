# base/

공식 Certified Ubuntu 22.04 이미지를 여기에 둔다 (계획서 3.2).

- ubuntu.com/download/amd → Zynq UltraScale+ MPSoC 개발 보드용 **Ubuntu Desktop 22.04 LTS** (ZCU102·104·106 공용)
- 받은 `.img.xz`를 그대로 넣으면 된다 (`.img`도 됨). 하나만 두거나 `config.env`의 `BASE_IMAGE=`로 지정.
- image 단계는 이 파일을 풀어(`build/image/base.img`) 복사본의 루트 파티션에만 파일을 넣는다.
  부트 파티션(BOOT.BIN 등)은 건드리지 않는다.
