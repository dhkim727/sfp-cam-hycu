# hw/

ZCU104 Vivado 설계의 XSA를 여기에 둔다.

- Vivado: File > Export > Export Hardware > **Include bitstream** 선택 (비트스트림 필수)
- `system.xsa`가 있으면 그것을, 없으면 이 폴더의 유일한 `.xsa`를 자동으로 쓴다.
  여러 개면 `config.env`의 `XSA=` 또는 `./build.sh --xsa <파일>`로 고른다.
- 계획서 4.1: ZCU104 보드 프리셋의 PS 설정은 바꾸지 않는다. 런타임 로드에서는 XSA의 PS 쪽 변경이 반영되지 않는다.
