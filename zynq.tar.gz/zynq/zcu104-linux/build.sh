#!/usr/bin/env bash
# ZCU104 SD 카드 이미지 빌드 — zcu104_linux_plan.md (공식 Ubuntu 22.04 + 런타임 PL 로드)
#
#   ./build.sh [단계] [--clean] [--xsa 파일] [--base 이미지]
#
#   단계   all(기본) | fetch | hw | dt | bit | bundle | image
#          status    — 단계별 상태만 보기
#          clean     — build/ out/ 삭제 (src/ base/ 는 남김)
#          distclean — src/ 까지 삭제
#   --clean  캐시를 무시하고 실행하는 단계들을 처음부터 다시 만든다
#   --xsa    hw/ 대신 이 XSA를 쓴다
#   --base   base/ 대신 이 공식 Ubuntu 이미지를 쓴다
#
# 흐름: XSA → system.bit.bin(bootgen) + pl.dtbo(DTG 오버레이, generic-uio 패치)
#       → bundle(보드에 넣을 파일 묶음, out/pl-update.tar.gz)
#       → image(공식 이미지의 루트 파일 시스템에 bundle을 넣은 out/sdcard.img)
# 공식 이미지의 BOOT.BIN·부트 스크립트·DTB는 그대로 둔다 (계획서 B단계: 재부팅하면 원상복구 가능).
# shellcheck disable=SC2153  # 대문자 설정 변수는 config.env에서 온다
set -Eeuo pipefail
umask 022   # 사용자 umask(002 등)와 상관없이 산출물·이미지 안 파일 권한을 같게

TOP=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
BUILD=$TOP/build
OUT=$TOP/out
SRC=$TOP/src
LOGDIR=$BUILD/logs
# shellcheck source=scripts/lib.sh
source "$TOP/scripts/lib.sh"
trap 'on_err $? $LINENO "$BASH_COMMAND"' ERR

# ===========================================================================
# 단계 정의:  이름 / 해시에 반영되는 선행 단계 / 순서만 필요한 선행 단계
# ===========================================================================
stage fetch  ""       ""
stage hw     ""       ""
stage dt     "hw"     "fetch"
stage bit    "hw"     ""
stage bundle "dt bit" ""
stage image  "bundle" ""

# ---------------------------------------------------------------------------
# fetch — device-tree-xlnx (DT_GEN=dtg일 때만)
# ---------------------------------------------------------------------------
inputs_fetch() { h_vars DTG_REPO DTG_TAG DT_GEN; }
outputs_fetch() { if [[ $DT_GEN == dtg ]]; then echo "$SRC/device-tree-xlnx/.git"; fi; }
stage_fetch() {
	if [[ $DT_GEN != dtg ]]; then
		info "DT_GEN=$DT_GEN — 받을 소스 없음"
		return 0
	fi
	need_cmd git
	mkdir -p "$SRC"
	git_fetch_tag device-tree-xlnx "$DTG_REPO" "$DTG_TAG" "$SRC/device-tree-xlnx"
}

# ---------------------------------------------------------------------------
# hw — XSA(zip)에서 비트스트림 꺼내기
# ---------------------------------------------------------------------------
inputs_hw() {
	local x
	x=$(resolve_xsa 2>/dev/null) || x=
	printf 'xsa %s\n' "${x:+$(sha256sum <"$x" | cut -d' ' -f1)}"
	h_vars BIT_NAME
}
outputs_hw() { echo "$BUILD/hw/system.bit"; }
stage_hw() {
	need_cmd unzip
	local xsa x bits=()
	xsa=$(resolve_xsa)
	info "XSA: $(rel "$xsa")  sha256 $(sha256sum <"$xsa" | cut -c1-16)…"
	x=$BUILD/hw/xsa
	xsa_unpack "$xsa" "$x"
	if [[ -z $(find "$x" -name psu_init_gpl.c -print -quit) ]]; then
		die "ZynqMP XSA가 아닙니다 (psu_init_gpl.c 없음). ZCU104 설계의 XSA를 넣으세요."
	fi
	if [[ -n $BIT_NAME ]]; then
		mapfile -t bits < <(find "$x" -type f -name "$BIT_NAME")
	else
		mapfile -t bits < <(find "$x" -type f -name '*.bit' | LC_ALL=C sort)
	fi
	case ${#bits[@]} in
	0) die "XSA에 비트스트림(.bit)이 없습니다. Vivado Export Hardware에서 'Include bitstream'을 고르세요." ;;
	1) install -m644 "${bits[0]}" "$BUILD/hw/system.bit" ;;
	*) die "XSA에 .bit가 여러 개입니다: ${bits[*]##*/} — config.env의 BIT_NAME으로 하나를 고르세요." ;;
	esac
	find "$x" -name '*.hwh' -exec cp {} "$BUILD/hw/" \;
	info "비트스트림: ${bits[0]##*/}"
}

# ---------------------------------------------------------------------------
# dt — PL 오버레이: DTG 오버레이 모드 → pl.dtsi → dtc -@ → generic-uio·firmware-name 패치
# ---------------------------------------------------------------------------
inputs_dt() {
	h_vars DT_GEN DT_BOARD DT_PROC DTG_TAG UIO_NODES FW_NAME PL_CLK0_HZ
	h_file "$TOP/scripts/dtg.tcl"
	if [[ $DT_GEN == dtg ]]; then h_git "$SRC/device-tree-xlnx"; fi
}
outputs_dt() { echo "$OUT/pl.dtbo $OUT/pl.dts"; }
stage_dt() {
	need_cmd dtc fdtget fdtput "${HOSTCC:-gcc}"
	local d=$BUILD/dt xsa src opts=() dtbo
	xsa=$(resolve_xsa)
	rm -rf "$d/gen" "$d/sdt"
	mkdir -p "$d/gen"
	case $DT_GEN in
	dtg)
		dtg_run "$xsa" "$SRC/device-tree-xlnx" "$d/gen" "$DT_PROC" "${DT_BOARD:--}" 1 "${FW_NAME%.bin}"
		src=$d/gen/pl.dtsi
		;;
	sdtgen)
		need_cmd lopper
		if [[ -n $DT_BOARD ]]; then opts+=(-board_dts "$DT_BOARD"); fi
		xrun sdtgen -xsa "$xsa" -dir "$d/sdt" "${opts[@]}"
		LOPPER_DTC_FLAGS="-b 0 -@" lopper -O "$d/gen" -f --enhanced "$d/sdt/system-top.dts" "$d/gen/linux.dts" \
			-- xlnx_overlay_dt cortexa53-zynqmp full "$d/sdt/pl.dtsi"
		src=$d/gen/pl.dtsi
		;;
	*) die "DT_GEN은 dtg 또는 sdtgen 이어야 합니다: $DT_GEN" ;;
	esac
	[[ -f $src ]] || die "오버레이 생성 결과가 없습니다: $(rel "$src")"

	dt_cpp "$d/pl.pp.dtsi" "$src" "$(dirname "$src")" "$(dirname "$src")/include"
	dtbo=$d/pl.dtbo
	dtc -@ -I dts -O dtb -o "$dtbo" "$d/pl.pp.dtsi"

	dtbo_set_uio "$dtbo"
	dtbo_set_firmware "$dtbo"
	dtbo_check_clock "$dtbo"

	mkdir -p "$OUT"
	install -m644 "$dtbo" "$OUT/pl.dtbo"
	dtc -q -I dtb -O dts -o "$OUT/pl.dts" "$OUT/pl.dtbo"
	info "out/pl.dtbo — 확인용 소스: out/pl.dts"
}

# 오버레이 안의 레이블 → 노드 경로 (dtc -@ 가 만든 __symbols__)
dtbo_path() { fdtget -t s "$1" /__symbols__ "$2" 2>/dev/null; }

dtbo_set_uio() {   # UIO_NODES 노드의 compatible을 "generic-uio"로 (계획서 4.2)
	local dtbo=$1 l p
	for l in $UIO_NODES; do
		p=$(dtbo_path "$dtbo" "$l") ||
			die "오버레이에 레이블 '$l'이 없습니다. config.env의 UIO_NODES를 고치세요.
    오버레이의 레이블: $(fdtget -p "$dtbo" /__symbols__ 2>/dev/null | tr '\n' ' ')"
		fdtput -t s "$dtbo" "$p" compatible generic-uio
		info "generic-uio: $l ($p)"
	done
}

dtbo_set_firmware() {   # fpga_full 조각의 firmware-name을 FW_NAME으로
	local dtbo=$1 f p=
	for f in $(fdtget -l "$dtbo" / 2>/dev/null); do
		if fdtget "$dtbo" "/$f/__overlay__" firmware-name >/dev/null 2>&1; then
			p=/$f/__overlay__
			break
		fi
	done
	if [[ -z $p ]]; then
		# firmware-name이 없으면 fpga_full을 대상으로 하는 조각에 새로 넣는다
		f=$(fdtget -t s "$dtbo" /__fixups__ fpga_full 2>/dev/null | tr ' ' '\n' | sed -n 's#^\(/fragment@[0-9]*\):target:0$#\1#p' | head -n1 || true)
		[[ -n $f ]] || die "오버레이에 fpga_full 대상 조각이 없습니다 (DTG 오버레이 모드 출력인지 확인)."
		p=$f/__overlay__
	fi
	fdtput -t s "$dtbo" "$p" firmware-name "$FW_NAME"
	info "firmware-name: $FW_NAME ($p)"
}

dtbo_check_clock() {   # PL 클럭(xlnx,fclk) 노드와 주파수 확인 (계획서 4.2)
	local dtbo=$1 l p compat rate found=0
	[[ $PL_CLK0_HZ =~ ^[0-9]+$ ]] || { warn "PL_CLK0_HZ가 숫자가 아님 — 클럭 확인 생략"; return 0; }
	while read -r l; do
		p=$(dtbo_path "$dtbo" "$l") || continue
		compat=" $(fdtget -t s "$dtbo" "$p" compatible 2>/dev/null || true) "
		[[ $compat == *" xlnx,fclk "* ]] || continue
		found=1
		rate=$(fdtget -t u "$dtbo" "$p" assigned-clock-rates 2>/dev/null || true)
		if [[ -z $rate ]]; then
			warn "PL 클럭 노드 $l에 assigned-clock-rates가 없습니다."
		elif ((rate * 100 < PL_CLK0_HZ * 99 || rate * 100 > PL_CLK0_HZ * 101)); then
			warn "PL 클럭 $l = $rate Hz — 기대값 PL_CLK0_HZ=$PL_CLK0_HZ 와 다릅니다. Vivado의 pl_clk0 설정을 확인하세요."
		else
			info "PL 클럭: $l = $rate Hz"
		fi
	done < <(fdtget -p "$dtbo" /__symbols__ 2>/dev/null)
	((found)) || warn "오버레이에 PL 클럭(xlnx,fclk) 노드가 없습니다. 런타임 로드 후 pl_clk0이 기본값일 수 있습니다."
	return 0
}

# ---------------------------------------------------------------------------
# bit — bootgen으로 FPGA Manager용 .bit.bin 만들기 (계획서 4.2)
# ---------------------------------------------------------------------------
inputs_bit() { h_vars FW_NAME; }
outputs_bit() { echo "$OUT/$FW_NAME"; }
stage_bit() {
	local d=$BUILD/bit
	install -m644 "$BUILD/hw/system.bit" "$d/system.bit"
	printf 'all:\n{\n\tsystem.bit\n}\n' >"$d/bit.bif"
	rm -f "$d/system.bit.bin"
	# -process_bitstream bin: 헤더를 떼고 바이트 순서를 바꾼 원시 비트스트림(<입력>.bin)을 만든다.
	# (-o 만 주면 부트 헤더가 붙은 부트 이미지가 나와 FPGA Manager가 못 읽는다)
	(cd "$d" && xrun bootgen -arch zynqmp -image bit.bif -process_bitstream bin -w)
	[[ -f $d/system.bit.bin ]] || die "bootgen 결과(system.bit.bin)가 없습니다."
	mkdir -p "$OUT"
	install -m644 "$d/system.bit.bin" "$OUT/$FW_NAME"
	info "out/$FW_NAME ($(stat -c %s "$OUT/$FW_NAME") B)"
}

# ---------------------------------------------------------------------------
# bundle — 보드 루트 파일 시스템에 들어갈 파일 묶음 (board/overlay + 비트스트림 + 오버레이 + 설정)
#          out/pl-update.tar.gz 는 이미 설치된 보드에 다시 굽지 않고 넣을 때 쓴다
# ---------------------------------------------------------------------------
inputs_bundle() {
	h_vars PL_NAME FW_NAME UDMABUF_SIZE UDMABUF_TAG
	h_dir "$TOP/board/overlay"
}
outputs_bundle() { echo "$BUILD/bundle/root $OUT/pl-update.tar.gz"; }
stage_bundle() {
	local d=$BUILD/bundle root=$BUILD/bundle/root
	rm -rf "$root"
	mkdir -p "$root"
	(cd "$TOP/board/overlay" && find . -type f ! -name .gitkeep -print0 | tar --null -T - -cf -) | tar -C "$root" -xf -

	install -D -m644 "$OUT/$FW_NAME" "$root/usr/lib/firmware/$FW_NAME"
	install -D -m644 "$OUT/pl.dtbo" "$root/usr/lib/firmware/$PL_NAME.dtbo"
	mkdir -p "$root/etc"
	cat >"$root/etc/pl-load.conf" <<-EOF
		# pl-load 설정 — zcu104-linux/build.sh가 config.env로 만든 파일
		PL_NAME=$PL_NAME
		PL_FIRMWARE=$FW_NAME
		PL_DTBO=/lib/firmware/$PL_NAME.dtbo
		UDMABUF_SIZE=$UDMABUF_SIZE
		UDMABUF_TAG=$UDMABUF_TAG
	EOF

	# 권한: 실행 파일만 755, 나머지 644 (복사 과정에서 권한이 바뀌어도 결과는 같게)
	find "$root" -type d -exec chmod 0755 {} +
	find "$root" -type f -exec chmod 0644 {} +
	find "$root/usr/local/sbin" "$root/usr/local/bin" -type f -exec chmod 0755 {} + 2>/dev/null || true

	(cd "$root" && find . -type f -print0 | LC_ALL=C sort -z |
		tar --null --no-recursion -T - --owner=0 --group=0 --numeric-owner -czf "$OUT/pl-update.tar.gz")
	(cd "$root" && find . -type f | LC_ALL=C sort) | sed 's#^\.#  #'
	info "out/pl-update.tar.gz"
}

# ---------------------------------------------------------------------------
# image — 공식 이미지 루트(ext4)에 bundle을 넣는다. root 권한 없이 debugfs로 직접 쓴다
# ---------------------------------------------------------------------------
resolve_base() {   # --base / config.env BASE_IMAGE → base/의 유일한 .img.xz / .img
	local p f=()
	if [[ -n ${BASE_IMAGE:-} ]]; then
		p=$(abspath "$BASE_IMAGE")
		[[ -f $p ]] || die "베이스 이미지가 없습니다: $p"
		printf '%s' "$p"
		return
	fi
	shopt -s nullglob
	f=("$TOP"/base/*.img.xz "$TOP"/base/*.img)
	shopt -u nullglob
	((${#f[@]} > 0)) || die "base/ 폴더에 공식 Ubuntu 이미지가 없습니다.
    ubuntu.com/download/amd 에서 'Zynq UltraScale+ MPSoC 개발 보드용 Ubuntu Desktop 22.04 LTS'를 받아
    base/에 넣거나 config.env의 BASE_IMAGE= 로 지정하세요. (계획서 3.2)"
	((${#f[@]} == 1)) || die "base/에 이미지가 여러 개입니다: ${f[*]##*/} — BASE_IMAGE= 로 고르세요."
	printf '%s' "${f[0]}"
}

base_id() {   # 큰 파일이라 내용 대신 경로·크기·수정 시각으로 식별
	local b
	b=$(resolve_base 2>/dev/null) || { echo none; return; }
	printf '%s|%s\n' "$b" "$(stat -c '%s|%Y' "$b")"
}

inputs_image() {
	printf 'base %s\n' "$(base_id)"
	h_vars ROOT_PART PL_AUTOLOAD TEXT_MODE_BOOT
}
outputs_image() { echo "$OUT/sdcard.img"; }

# find_root_part <이미지> → "번호 바이트오프셋 레이블"
find_root_part() {
	local img=$1 n start size sb lab best='' bestsize=0
	while read -r n start size; do
		sb=$(dumpe2fs -h "$img?offset=$((start * 512))" 2>/dev/null) || continue   # ext2/3/4가 아니면 건너뜀
		lab=$(sed -n 's/^Filesystem volume name:[[:space:]]*//p' <<<"$sb")
		[[ $lab == '<none>' ]] && lab=
		if [[ $ROOT_PART != auto ]]; then
			if [[ $n == "$ROOT_PART" ]]; then
				echo "$n $((start * 512)) $lab"
				return 0
			fi
		elif [[ $lab == writable ]]; then
			echo "$n $((start * 512)) $lab"
			return 0
		elif ((size > bestsize)); then
			bestsize=$size
			best="$n $((start * 512)) $lab"
		fi
	done < <(sfdisk -d "$img" | sed -n 's#^.*[^0-9]\([0-9][0-9]*\)[[:space:]]*:[[:space:]]*start=[[:space:]]*\([0-9]*\),[[:space:]]*size=[[:space:]]*\([0-9]*\).*#\1 \2 \3#p')
	[[ -n $best ]] || return 1
	echo "$best"
}

stage_image() {
	need_cmd debugfs dumpe2fs e2fsck sfdisk xz
	local d=$BUILD/image base id part off label img root=$BUILD/bundle/root f rel dir fails=0
	base=$(resolve_base)
	id=$(base_id)

	# 1) 베이스 이미지 풀기 (같은 파일이면 build/image/base.img 재사용)
	if [[ ! -f $d/base.img || $(cat "$d/base.id" 2>/dev/null) != "$id" ]]; then
		info "베이스 이미지 풀기: $(rel "$base") (수 분 걸릴 수 있음)"
		rm -f "$d/base.img" "$d/base.id"
		case $base in
		*.xz) xz -dc "$base" | dd of="$d/base.img.part" bs=4M conv=sparse status=none ;;
		*) cp --sparse=always "$base" "$d/base.img.part" ;;
		esac
		mv "$d/base.img.part" "$d/base.img"
		echo "$id" >"$d/base.id"
	fi

	read -r part off label < <(find_root_part "$d/base.img") ||
		die "베이스 이미지에서 ext4 루트 파티션을 찾지 못했습니다. config.env의 ROOT_PART를 지정하세요."
	info "루트 파티션: ${part}번 (레이블 '${label:-}', 오프셋 $off)"

	img=$d/sdcard.img
	rm -f "$img"
	cp --sparse=always --reflink=auto "$d/base.img" "$img"

	# 2) debugfs 명령 만들기: 디렉터리 → 파일(지우고 다시 쓰기, root 소유, 권한) → 서비스 링크
	{
		while IFS= read -r -d '' dir; do
			echo "mkdir /${dir#./}"
		done < <(cd "$root" && find . -mindepth 1 -type d -print0 | LC_ALL=C sort -z)
		while IFS= read -r -d '' f; do
			rel=/${f#./}
			echo "cd $(dirname "$rel")"
			echo "rm $(basename "$rel")"
			echo "write $root$rel $(basename "$rel")"
			printf 'sif %s mode 0%o\n' "$rel" $((0100000 | 0$(stat -c %a "$root$rel")))
			echo "sif $rel uid 0"
			echo "sif $rel gid 0"
		done < <(cd "$root" && find . -type f -print0 | LC_ALL=C sort -z)
		echo "cd /"
		echo "mkdir /etc/systemd/system/multi-user.target.wants"
		echo "rm /etc/systemd/system/multi-user.target.wants/pl-load.service"
		if [[ $PL_AUTOLOAD == 1 ]]; then
			echo "symlink /etc/systemd/system/multi-user.target.wants/pl-load.service /etc/systemd/system/pl-load.service"
		fi
		if [[ $TEXT_MODE_BOOT == 1 ]]; then
			echo "rm /etc/systemd/system/default.target"
			echo "symlink /etc/systemd/system/default.target /lib/systemd/system/multi-user.target"
		fi
	} >"$d/inject.cmds"
	debugfs -w -f "$d/inject.cmds" "$img?offset=$off" >"$d/inject.log" 2>&1 ||
		die "debugfs 실패 — $(rel "$d/inject.log")"

	# 3) 검증: 넣은 파일을 다시 꺼내 내용·권한 비교
	while IFS= read -r -d '' f; do
		rel=/${f#./}
		rm -f "$d/check.tmp"
		debugfs -R "dump $rel $d/check.tmp" "$img?offset=$off" >/dev/null 2>&1 || true
		if ! cmp -s "$root$rel" "$d/check.tmp"; then
			warn "이미지 안 $rel 내용이 다릅니다"
			fails=1
		fi
		if ! debugfs -R "stat $rel" "$img?offset=$off" 2>/dev/null | grep -q "Mode:  0$(stat -c '%a' "$root$rel")"; then
			warn "이미지 안 $rel 권한이 다릅니다"
			fails=1
		fi
	done < <(cd "$root" && find . -type f -print0)
	rm -f "$d/check.tmp"
	((fails == 0)) || die "주입 검증 실패 — $(rel "$d/inject.log")"

	if ! e2fsck -fn "$img?offset=$off" >"$d/e2fsck.log" 2>&1; then
		warn "e2fsck가 문제를 보고했습니다 — $(rel "$d/e2fsck.log")"
	fi

	mkdir -p "$OUT"
	mv "$img" "$OUT/sdcard.img"
	info "out/sdcard.img — 공식 이미지 + PL 자동 로드 (pl-load.service: $([[ $PL_AUTOLOAD == 1 ]] && echo 켬 || echo 끔))"
}

# ===========================================================================
# 메인
# ===========================================================================
usage() { awk 'NR > 1 && /^# shellcheck/ { next } NR > 1 && /^#/ { sub(/^# ?/, ""); print; next } NR > 1 { exit }' "$0"; }

main() {
	local target=all a
	while (($#)); do
		a=$1
		shift
		case $a in
		--clean) CLEAN=1 ;;
		--xsa) XSA_CLI=${1:?--xsa 다음에 파일 경로}; shift ;;
		--xsa=*) XSA_CLI=${a#--xsa=} ;;
		--base) BASE_CLI=${1:?--base 다음에 이미지 경로}; shift ;;
		--base=*) BASE_CLI=${a#--base=} ;;
		-h | --help) usage; exit 0 ;;
		-*) die "알 수 없는 옵션: $a (./build.sh --help)" ;;
		*) target=$a ;;
		esac
	done

	[[ $TOP != *[[:space:]]* ]] || die "폴더 경로에 공백이 있으면 안 됩니다: $TOP"
	load_config
	[[ -n ${XSA_CLI:-} ]] && XSA=$XSA_CLI
	[[ -n ${BASE_CLI:-} ]] && BASE_IMAGE=$BASE_CLI
	[[ -z ${XSA:-} || -f $(abspath "$XSA") ]] || die "XSA 파일이 없습니다: $XSA"

	case $target in
	status) show_status; return ;;
	clean) rm -rf "$BUILD" "$OUT"; info "build/ out/ 삭제"; return ;;
	distclean) rm -rf "$BUILD" "$OUT" "$SRC"; info "build/ out/ src/ 삭제"; return ;;
	all) target=image ;;
	esac
	is_stage "$target" || die "알 수 없는 단계: $target (./build.sh --help)"

	mkdir -p "$BUILD" "$LOGDIR"
	exec 9>"$BUILD/.lock"
	flock -n 9 || die "다른 build.sh가 이 폴더에서 실행 중입니다."

	run_stage "$target"

	case $target in
	image)
		info "완료. SD 카드에 쓰기 (sdX는 lsblk로 확인):"
		echo "    sudo dd if=$(rel "$OUT/sdcard.img") of=/dev/sdX bs=4M conv=fsync status=progress"
		;;
	bundle)
		info "이미 설치된 보드에 넣기:"
		echo "    scp out/pl-update.tar.gz ubuntu@<보드>:"
		echo "    ssh ubuntu@<보드> 'sudo tar -C / --keep-directory-symlink -xzf pl-update.tar.gz && sudo systemctl daemon-reload && sudo systemctl enable --now pl-load'"
		;;
	esac
}

main "$@"
