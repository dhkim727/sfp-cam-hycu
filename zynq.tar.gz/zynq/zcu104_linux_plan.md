# ZCU104 Linux 구성 계획

> 시스템 1 송신부(ZCU104)의 Linux 구성 계획
> 기본 경로: Certified Ubuntu 22.04 LTS 공식 이미지 + 런타임 PL 로드 · 작성: 2026.10
> 짝 문서: `z7015_linux_plan.md` (수신부)

---

## 1. 목표와 범위

- oCam-5CRO-U(USB 3.0 UVC) 프레임을 Linux(V4L2)로 받아 링 버퍼에 쌓고, PL의 AXI DMA → Aurora로 송신한다.
- 공식 Ubuntu 22.04 이미지로 빠르게 시작하고, 우리 PL은 부팅 후 런타임으로 올린다.
- 안정되면 xlnx-config 커스텀 플랫폼(PAC)으로 부팅 구성에 고정한다.
- ZCU104용 공식 Ubuntu 24.04 이미지는 없다. 24.04 공식 서버 이미지는 Kria KV260·KR260·KD240 전용이고, ZCU102/104/106에는 22.04 데스크톱만 제공된다. 24.04가 필요하면 6장의 자체 구성 경로를 쓴다.

---

## 2. 단계 로드맵

| 단계 | 내용 | 부팅 자산 변경 | 목적 |
|---|---|---|---|
| A | 공식 Ubuntu 22.04 설치 | 없음 | 카메라 · USB 3.0 확인 |
| B | 런타임 PL 로드 + 커널 모듈 | 없음 | 송신 경로 검증 |
| C | xlnx-config PAC | BOOT.BIN 교체 (골든 자산 보존) | 부팅 구성 고정, reserved-memory |
| D (선택) | PetaLinux 2025.2 + Ubuntu 24.04 arm64 | 전부 자체 구성 | 커널 6.12, 툴 버전 통일 |

- 권장 순서는 A → B → C다. B는 부팅 자산을 전혀 건드리지 않아서 실패해도 재부팅이면 원상복구된다.

---

## 3. 단계 A — Ubuntu 22.04 설치

### 3.1 준비물

- ZCU104 (Rev 1.0 이상)
- microSD 카드 8 GB 이상 (16 GB 권장)
- 인터넷이 되는 이더넷 케이블, UART용 micro-USB 케이블
- 선택: DisplayPort 모니터, 키보드·마우스용 USB 허브

### 3.2 설치 절차

1. ubuntu.com/download/amd에서 Zynq UltraScale+ MPSoC 개발 보드용 **Ubuntu Desktop 22.04 LTS**를 받는다. ZCU102·104·106 공용 이미지이며 2032년 4월까지 지원된다.
2. SD 카드에 굽는다 (Balena Etcher, Win32 Disk Imager, dd 중 아무거나).

   ```
   xzcat <이미지>.img.xz | sudo dd of=/dev/sdX bs=4M conv=fsync status=progress
   ```

3. SW6을 SD 부트로 맞춘다: **1번 ON, 2·3·4번 OFF**
4. UART를 115200 8N1로 연다. FT4232H가 COM 포트 4개를 만드는데, 콘솔은 보통 두 번째 포트(리눅스 호스트라면 `/dev/ttyUSB1`)다. 이더넷을 연결하고 전원을 켠다.
5. 로그인: **ubuntu / ubuntu**. 첫 로그인 후 비밀번호 변경을 요구한다.
6. 업데이트와 보드 관리 도구 설치

   ```
   sudo apt update && sudo apt upgrade
   sudo snap install xlnx-config --classic --channel=2.x
   xlnx-config.sysinit
   ```

7. 텍스트 모드 부팅으로 바꿔 메모리를 확보한다 (2 GB 중 상당 부분을 링 버퍼로 쓸 예정).

   ```
   sudo systemctl set-default multi-user.target
   ```

### 3.3 설치 후 첫 확인 — 카메라

```
lsusb -t                                     # oCam이 5000M(USB 3.0)으로 붙었는지
sudo apt install v4l-utils
v4l2-ctl -d /dev/video0 --list-formats-ext   # 지원 포맷·해상도·fps 목록
v4l2-ctl -d /dev/video0 --set-fmt-video=width=1280,height=960,pixelformat=<목록의 YUV FourCC> \
         --stream-mmap --stream-count=300    # 실측 fps 확인
```

- 기대값 (oCam-5CRO-U, USB 3.0, YUV): 2592×1944 @7.5, 1920×1080 @15, 1280×960 @30, 1280×720 @30, 640×480 @120, 320×240 @120 fps
- MJPEG(1920×1080 @30, 1280×720 @45)은 제조사가 리눅스에서만 지원한다고 명시 → ZCU104에서는 사용 가능
- 링크가 480M으로 잡히면 허브나 OTG 어댑터가 USB 2.0이다. 이 경우 펌웨어가 USB 2.0 모드로 떨어져 1080p가 7.5 fps가 된다.

### 3.4 주의

- 이 릴리스는 **SD 부트만 지원**한다.
- SD 카드의 BOOT.BIN은 ImgSel이라는 맞춤 FSBL 하나만 든 특수 파일이다. 직접 교체하지 말고, 바꿀 때는 C단계(xlnx-config)를 거친다.
- 콘솔 출력이 UART와 DisplayPort로 나뉜다. UART에서 부팅 로그가 중간에 끊겨 보여도 정상이다.
- 첫 부팅 때 보드별 기본 비트스트림과 디바이스 트리 조합이 자동으로 설정된다.
- AMD 위키의 "Getting Started with Certified Ubuntu 22.04 LTS" 페이지에 ZCU104 전용 주의 사항 절이 있다. 설치 전에 확인한다.

---

## 4. 단계 B — 런타임 PL 로드 + 커널 모듈

### 4.1 Vivado 설계 규칙

- **ZCU104 보드 프리셋의 PS 설정은 손대지 않는다** (MIO, DDR, USB, GTR 등).
- PL에 필요한 PS-PL 인터페이스만 켠다: `S_AXI_HP0_FPD`, `M_AXI_HPM0_FPD`, `pl_clk0`, `pl_ps_irq0`
- 이유: 런타임 로드에서는 PS가 이미 Ubuntu 부팅 펌웨어로 초기화된 상태다. XSA의 PS 쪽 변경은 반영되지 않고, 오버레이로 바꿀 수 있는 것은 PL 클럭 주파수와 HP 포트 폭 정도다.

### 4.2 호스트에서 만들 파일

| 파일 | 만드는 법 |
|---|---|
| `system.bit.bin` | bootgen으로 FPGA Manager용 형식 변환 |
| `pl.dtbo` | DTG를 오버레이 모드로 돌려 `pl.dtsi` 생성 → 수정 → dtc |

```
echo 'all:{ system.bit }' > bit.bif
bootgen -image bit.bif -arch zynqmp -o system.bit.bin -w
dtc -@ -I dts -O dtb -o pl.dtbo pl.dtsi
```

`pl.dtsi`에서 손볼 것

- AXI DMA, link_ctrl, tx_test_gen 노드의 compatible을 `"generic-uio"`로 바꾼다.
- `firmware-name = "system.bit.bin";`이 들어 있는지 확인한다.
- PL 클럭(pl_clk0 = 150 MHz)을 설정하는 노드가 있는지 확인한다.

### 4.3 보드에서 커널 지원 확인

```
ls /sys/class/fpga_manager/                   # fpga0 이 있어야 함
ls /sys/kernel/config/device-tree/overlays    # configfs 오버레이 인터페이스
ls /proc/device-tree/__symbols__ | head       # 베이스 DTB 레이블 정보
```

- configfs 오버레이 인터페이스가 없으면 비트스트림과 오버레이를 같이 올릴 수 없다 → C단계(PAC)로 바로 넘어간다.
- `__symbols__`가 없으면 오버레이가 `&fpga_full` 같은 레이블을 못 찾는다 → 오버레이의 대상을 레이블 대신 경로(`target-path`)로 적는다.

### 4.4 로드와 언로드

```
sudo cp system.bit.bin /lib/firmware/
sudo mkdir /sys/kernel/config/device-tree/overlays/sys1
sudo sh -c 'cat pl.dtbo > /sys/kernel/config/device-tree/overlays/sys1/dtbo'

# 언로드 (오버레이가 여러 개면 적용한 역순으로)
sudo rmdir /sys/kernel/config/device-tree/overlays/sys1
```

- Xilinx의 fpgautil이 설치돼 있다면 `sudo fpgautil -b system.bit.bin -o pl.dtbo`로도 된다.

### 4.5 커널 모듈

```
sudo apt install linux-headers-$(uname -r) build-essential git
git clone https://github.com/ikwzm/udmabuf && cd udmabuf && make

sudo modprobe uio_pdrv_genirq of_id=generic-uio
sudo insmod u-dma-buf.ko udmabuf0=268435456      # 256 MiB
ls /dev/uio* /dev/udmabuf0
```

- `apt upgrade`로 커널이 바뀌면 u-dma-buf를 다시 빌드해야 한다. 개발 중에는 커널 패키지를 `apt-mark hold`로 묶어 두거나 DKMS로 등록한다.
- 처음에는 u-dma-buf를 `O_SYNC`로 열어 캐시 동기화를 없애고, DMA 완료는 인터럽트 대신 폴링으로 확인한다. 7.5~120 fps에서는 폴링 부담이 거의 없다.

### 4.6 CMA 크기

```
grep -i cma /proc/meminfo
```

- 런타임 오버레이로는 reserved-memory를 추가할 수 없으므로, u-dma-buf가 CMA에서 메모리를 받는다.
- 부족하면 `/etc/default/flash-kernel`의 `LINUX_KERNEL_CMDLINE`에 `cma=1100M`을 넣고 `sudo flash-kernel` 후 재부팅한다.
- 링 크기 기준: 처음 검증은 1080p 4 MiB 슬롯 64개(256 MiB)면 충분하다. 1 GiB는 5 MP 100장 버스트를 무손실로 담을 때만 필요하다.

### 4.7 함께 확인할 것

- **PL 리셋**: 로드 후 IP가 응답하지 않으면 pl_resetn0이 해제된 상태인지 확인한다. 부팅 펌웨어가 이미 풀어 둔 경우가 보통이지만, 필요하면 GPIO로 리셋 펄스를 한 번 준다.
- **FMC 전원**: VADJ 1.8 V 설정과 IAM 어댑터 FRU 재기록은 OS와 무관하게 필요하다 (System Controller UI / PowIRCenter). 어댑터의 I2C 전압 점퍼는 VADJ 쪽으로 둔다.

---

## 5. 단계 C — xlnx-config 커스텀 플랫폼(PAC)

### 5.1 개념

- xlnx-config는 표준 플랫폼 대신 커스텀 하드웨어 플랫폼을 올리기 위한 도구다. 커스텀 부팅 자산(비트스트림, 펌웨어 등)을 설치하면서 Certified Ubuntu에 들어 있던 **골든 부팅 자산은 그대로 보존**한다.
- 커스텀 자산은 PAC(Platform Assets Container) 폴더 구조로 넣는다.
- 보드 디렉터리에 bootgen.bif가 있으면, 활성화할 때 xlnx-config가 그 bif로 bootgen을 돌려 새 부팅 자산을 만든다. bif에는 반드시 U-Boot가 들어가야 한다.

### 5.2 PAC 구조

```
/boot/firmware/xlnx-config/sys1/     (또는 /usr/local/share/xlnx-config/sys1/)
└── hwconfig/
    └── cfg1/
        ├── manifest.yaml
        └── zcu104/
            ├── bootgen.bif
            ├── <FSBL>
            ├── <비트스트림>
            └── <기타 부팅 자산>
```

### 5.3 부팅 자산 만들기 — 최소 변경 원칙

1. 먼저 현재 활성화된 기본 구성의 bootgen.bif를 열어, 어떤 자산(FSBL, PMUFW, ATF, U-Boot, DTB)이 어떤 순서·주소로 들어가는지 확인한다.
2. 우리 XSA로 **FSBL과 비트스트림**을 새로 만든다. PS 설정을 바꾸지 않았다면 PMUFW·ATF·U-Boot는 Ubuntu 기본 자산 재사용부터 시도한다. Ubuntu 부트 스크립트와의 호환을 지키는 가장 안전한 방법이다.
3. **DTB 전략**: 이 이미지의 ZCU104 기준 플랫폼은 2022.1 PetaLinux BSP 기반이라 커널이 우리 툴(2025.2)보다 오래됐다. 2025.2 툴로 만든 PS 쪽 노드가 이 커널과 맞지 않을 수 있으므로, Ubuntu의 현재 DTB를 바탕으로 PL 노드와 reserved-memory(링 버퍼 1 GiB)만 추가한다.
4. DTB가 BIF의 파티션으로 들어가는지, 부트 스크립트가 어떤 DTB를 커널에 넘기는지는 활성화 전에 기본 구성의 bif와 부트 스크립트로 확인한다.

### 5.4 활성화와 복구

```
xlnx-config -q                 # PAC 목록과 활성 상태 확인
sudo xlnx-config -a cfg1       # 활성화
sudo reboot
xlnx-config -q                 # cfg1에 * 표시 확인
```

- 부팅이 안 되면 골든 자산으로 되돌린다 (xlnx-config의 기본 구성 재활성화, 최악의 경우 SD 카드를 공식 이미지로 다시 굽기).

---

## 6. 단계 D (선택) — PetaLinux 2025.2 + Ubuntu 24.04 arm64

### 6.1 언제 쓰나

- 커널 6.12와 툴 2025.2로 버전을 맞추고 싶을 때
- reserved-memory나 DT를 제약 없이 바꾸고 싶을 때
- Ubuntu 24.04가 꼭 필요할 때 (공식 이미지가 없으므로 이 경로뿐)

### 6.2 구성

- PetaLinux 2025.2로 XSA에서 BOOT.BIN(FSBL, PMUFW, ATF, 비트스트림, U-Boot), Image, system.dtb, boot.scr를 만든다.
- `petalinux-config`에서 rootfs 유형을 **EXT4 (SD/eMMC)**, 장치를 `/dev/mmcblk0p2`로 바꾼다.
- Ubuntu 24.04 arm64 rootfs는 `z7015_linux_plan.md`의 rootfs 단계를 그대로 재사용한다. 아키텍처만 `arm64`, suite를 `noble`, 미러를 `http://ports.ubuntu.com/ubuntu-ports`로 바꾼다.
- PetaLinux가 만든 커널 모듈(`/lib/modules`)을 Ubuntu rootfs에 복사한다.
- 커널 설정에는 systemd 필수 옵션 조각을 똑같이 넣는다. snap을 쓸 거라면 SquashFS와 AppArmor도 켜고, 안 쓸 거라면 snapd를 빼는 것이 간단하다.
- PetaLinux는 2025.2 릴리스 노트에 지원 종료 예고가 있으므로, 장기적으로는 Yocto 직접 플로우를 고려한다.

---

## 7. ZCU104 소프트웨어 구성 (camtx)

| 구성 | 내용 |
|---|---|
| 캡처 스레드 | V4L2 MMAP 버퍼 → 32 B 헤더 + memcpy → 링 슬롯 |
| 송신 스레드 | 버스트(순서대로·대기) / 스트림(최신 프레임으로 건너뜀) 스케줄, AXI DMA를 UIO로 구동 |
| 제어 스레드 | CLI·소켓 트리거, link_ctrl의 UFC 수신 인터럽트 |
| 장치 노드 | `/dev/video0`, `/dev/udmabuf0`, `/dev/uio0..N` |

- AXI DMA는 5 MP 프레임(10.08 MB)을 한 번에 보내도록 버퍼 길이 레지스터를 24비트 이상으로 설정한다.
- 슬롯 크기는 포맷 협상 결과로 정한다: 헤더 32 B + 프레임, 4 KiB 정렬.

---

## 8. 마일스톤

| 단계 | 내용 | 통과 기준 |
|---|---|---|
| Z1 | Ubuntu 22.04 설치 | 로그인, apt 업데이트 완료 |
| Z2 | 카메라 확인 | `lsusb -t`에 5000M, 모드별 fps 달성 |
| Z3 | 런타임 PL 로드 | 오버레이 적용, `/dev/uio*` · `/dev/udmabuf0` 생성 |
| Z4 | 링크 (tx_test_gen) | Z7015 / 호스트에서 테스트 프레임 수신 |
| Z5 | 카메라 버스트 | camtx로 100장 전송, SEQ 연속 |
| Z6 | PAC 고정 | 재부팅 후 우리 PL·DTB로 자동 부팅 |

---

## 9. 리스크와 대응

| 리스크 | 대응 |
|---|---|
| configfs 오버레이 미지원 | 커널 지원부터 확인, 없으면 C단계(PAC)로 진행 |
| 베이스 DTB에 `__symbols__` 없음 | 오버레이 대상을 `target-path`로 작성 |
| PS 설정 불일치 | 보드 프리셋 PS 설정 유지, PL 인터페이스만 추가 |
| PL 리셋 미해제 | pl_resetn0 상태 확인, GPIO로 리셋 펄스 |
| 커널(2022.1 BSP 기반)과 2025.2 DT 차이 | 오버레이는 PL 노드만, PAC는 Ubuntu DTB 기반으로 수정 |
| CMA 부족 | `cma=` 커널 인자로 확대 (flash-kernel) |
| USB 2.0 강등 | USB 3.0 지원 허브·OTG 사용, `lsusb -t`로 확인 |
| 커널 업데이트로 모듈 깨짐 | 커널 패키지 hold 또는 DKMS |
| FMC VADJ · FRU | 시스템 컨트롤러로 VADJ 1.8 V, 어댑터 FRU 재기록 |

---

## 10. 참고 자료

- Ubuntu for AMD 다운로드: https://ubuntu.com/download/amd
- Getting Started with Certified Ubuntu 22.04 LTS for Xilinx Devices: https://xilinx-wiki.atlassian.net/wiki/spaces/A/pages/2363129857
- Booting Certified Ubuntu for Xilinx Devices: https://xilinx-wiki.atlassian.net/wiki/spaces/A/pages/2036826124
- xlnx-config Snap: https://xilinx-wiki.atlassian.net/wiki/spaces/A/pages/2057043969
- Solution ZynqMP PL Programming: https://xilinx-wiki.atlassian.net/wiki/spaces/A/pages/18841847
- u-dma-buf: https://github.com/ikwzm/udmabuf
- WITHROBOT oCam: https://github.com/withrobot/oCam
