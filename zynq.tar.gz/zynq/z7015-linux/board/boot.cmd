# U-Boot 부팅 스크립트 (계획서 5.7) — image 단계가 boot.scr로 변환한다
#   mkimage -A arm -T script -C none -d boot.cmd boot.scr
# 순서: 비트스트림 → 커널 → DTB
#
# 비트스트림은 loadaddr 대신 bit_addr_r에 올린다. 이 U-Boot의 loadaddr 기본값은 0x0이라
# OCM이 매핑된 구간과 겹칠 수 있다. 0x06000000은 커널(0x02000000)·DTB(0x01f00000)와 겹치지 않는다.
setenv bit_addr_r 0x06000000

if load mmc 0:1 ${bit_addr_r} system.bit; then
	fpga loadb 0 ${bit_addr_r} ${filesize}
else
	echo "system.bit not found - skipping PL load"
fi

load mmc 0:1 ${kernel_addr_r} zImage
load mmc 0:1 ${fdt_addr_r} system.dtb
# root= 는 config.env의 ROOT_DEV와 같아야 한다
setenv bootargs console=ttyPS0,115200 root=/dev/mmcblk0p2 rw rootwait
bootz ${kernel_addr_r} - ${fdt_addr_r}
