#!/usr/bin/env bash
# Z7015 Linux SD 카드 이미지 빌드 — z7015_linux_plan.md
#
#   ./build.sh [단계] [--clean] [--xsa 파일] [-j N]
#
#   단계   all(기본) | fetch | hw | dt | uboot | kernel | rootfs | image
#          status    — 단계별 상태만 보기
#          clean     — build/ out/ 삭제 (src/ dl/ 는 남김)
#          distclean — src/ 까지 삭제
#   --clean  캐시를 무시하고 실행하는 단계들을 처음부터 다시 만든다
#   --xsa    hw/ 대신 이 XSA를 쓴다
#
# 단계 사이 변경 감지는 입력의 sha256 (build/<단계>/.hash). 앞 단계가 오래됐으면 같이 돈다.
#   XSA 변경        → hw → dt → uboot → image
#   board.dtsi      → dt → uboot → image
#   uboot.config    → uboot → image
#   커널 소스·설정  → kernel → image
#   배포판·overlay  → rootfs → image
#   boot.cmd        → image
# shellcheck disable=SC2153  # 대문자 설정 변수는 config.env에서 온다
set -Eeuo pipefail
umask 022   # 사용자 umask(002 등)와 상관없이 산출물·이미지 안 파일 권한을 같게

TOP=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
BUILD=$TOP/build
OUT=$TOP/out
SRC=$TOP/src
DL=$TOP/dl
LOGDIR=$BUILD/logs
# shellcheck source=scripts/lib.sh
source "$TOP/scripts/lib.sh"
trap 'on_err $? $LINENO "$BASH_COMMAND"' ERR

# ===========================================================================
# 단계 정의:  이름 / 해시에 반영되는 선행 단계 / 순서만 필요한 선행 단계
# ===========================================================================
stage fetch  ""                         ""
stage hw     ""                         ""
stage dt     "hw"                       "fetch"
stage uboot  "hw dt"                    "fetch"
stage kernel ""                         "fetch"
stage rootfs ""                         ""
stage image  "hw dt uboot kernel rootfs" ""

# ---------------------------------------------------------------------------
# fetch — u-boot-xlnx, linux-xlnx, device-tree-xlnx 를 태그 고정으로 src/ 에
# ---------------------------------------------------------------------------
repos() {   # 이름 URL 태그
	echo "u-boot-xlnx $UBOOT_REPO $UBOOT_TAG"
	echo "linux-xlnx $LINUX_REPO $LINUX_TAG"
	if [[ $DT_GEN == dtg ]]; then echo "device-tree-xlnx $DTG_REPO $DTG_TAG"; fi
}
inputs_fetch() { h_vars UBOOT_REPO UBOOT_TAG LINUX_REPO LINUX_TAG DTG_REPO DTG_TAG DT_GEN; }
outputs_fetch() { local n u t; while read -r n u t; do echo "$SRC/$n/.git"; done < <(repos); }
stage_fetch() {
	need_cmd git
	mkdir -p "$SRC"
	local n u t
	while read -r n u t; do git_fetch_tag "$n" "$u" "$t" "$SRC/$n"; done < <(repos)
	while read -r n u t; do
		printf '%-18s %-24s %s\n' "$n" "$(git -C "$SRC/$n" describe --tags 2>/dev/null || echo '?')" "$(git -C "$SRC/$n" rev-parse HEAD)"
	done < <(repos) >"$BUILD/fetch/versions.txt"
	cat "$BUILD/fetch/versions.txt"
}

# ---------------------------------------------------------------------------
# hw — XSA(zip)에서 ps7_init_gpl.c/h, 비트스트림, hwh 꺼내기
# ---------------------------------------------------------------------------
inputs_hw() {
	local x
	x=$(resolve_xsa 2>/dev/null) || x=
	printf 'xsa %s\n' "${x:+$(sha256sum <"$x" | cut -d' ' -f1)}"
	h_vars BIT_NAME
}
outputs_hw() {
	echo "$BUILD/hw/ps7_init_gpl.c $BUILD/hw/ps7_init_gpl.h"
	if [[ -f $BUILD/hw/has-bitstream ]]; then echo "$OUT/system.bit"; fi   # XSA에 .bit가 있었을 때만
}
stage_hw() {
	need_cmd unzip
	local xsa x c h bits=()
	xsa=$(resolve_xsa)
	info "XSA: $(rel "$xsa")  sha256 $(sha256sum <"$xsa" | cut -c1-16)…"
	x=$BUILD/hw/xsa
	xsa_unpack "$xsa" "$x"

	if [[ -n $(find "$x" -name psu_init_gpl.c -print -quit) ]]; then
		die "ZynqMP XSA입니다 (psu_init_gpl.c). Zynq-7000(Z7015) XSA를 넣으세요."
	fi
	c=$(find_one "$x" ps7_init_gpl.c) || die "XSA에 ps7_init_gpl.c가 없거나 여러 개입니다."
	h=$(find_one "$x" ps7_init_gpl.h) || die "XSA에 ps7_init_gpl.h가 없거나 여러 개입니다."
	install -m644 "$c" "$BUILD/hw/ps7_init_gpl.c"
	install -m644 "$h" "$BUILD/hw/ps7_init_gpl.h"
	find "$x" -name '*.hwh' -exec cp {} "$BUILD/hw/" \;

	mkdir -p "$OUT"
	if [[ -n $BIT_NAME ]]; then
		mapfile -t bits < <(find "$x" -type f -name "$BIT_NAME")
	else
		mapfile -t bits < <(find "$x" -type f -name '*.bit' | LC_ALL=C sort)
	fi
	case ${#bits[@]} in
	0)
		warn "XSA에 비트스트림(.bit)이 없습니다. PL 없이 부팅합니다 (boot.cmd가 fpga loadb를 건너뜀).
    PL까지 올리려면 Export Hardware에서 'Include bitstream'을 고르세요."
		rm -f "$OUT/system.bit" "$BUILD/hw/has-bitstream"
		;;
	1)
		# boot.cmd가 고정 이름을 쓰도록 system.bit로 통일 (계획서 5.2)
		install -m644 "${bits[0]}" "$OUT/system.bit"
		touch "$BUILD/hw/has-bitstream"
		info "비트스트림: ${bits[0]##*/} → out/system.bit"
		;;
	*) die "XSA에 .bit가 여러 개입니다: ${bits[*]##*/} — config.env의 BIT_NAME으로 하나를 고르세요." ;;
	esac
}

# ---------------------------------------------------------------------------
# dt — DTG(또는 SDTGen+lopper) + board/board.dtsi → Linux용 system.dtb, U-Boot용 DTS
# ---------------------------------------------------------------------------
inputs_dt() {
	h_vars DT_GEN DT_BOARD DT_PROC LINUX_TAG DTG_TAG
	h_file "$TOP/board/board.dtsi" "$TOP/scripts/dtg.tcl"
	if [[ $DT_GEN == dtg ]]; then h_git "$SRC/device-tree-xlnx"; fi
}
outputs_dt() { echo "$OUT/system.dtb $BUILD/dt/system.pp.dts"; }
stage_dt() {
	need_cmd dtc "${HOSTCC:-gcc}"
	local d=$BUILD/dt top xsa opts=()
	xsa=$(resolve_xsa)
	mkdir -p "$d/gen"
	case $DT_GEN in
	dtg)
		dtg_run "$xsa" "$SRC/device-tree-xlnx" "$d/gen" "$DT_PROC" "${DT_BOARD:--}" 0 -
		top=$d/gen/system-top.dts
		;;
	sdtgen)
		# DTG 폐기 대비 경로 (계획서 5.3): SDTGen → lopper gen_domain_dts
		need_cmd lopper
		if [[ -n $DT_BOARD ]]; then opts+=(-board_dts "$DT_BOARD"); fi
		xrun sdtgen -xsa "$xsa" -dir "$d/sdt" "${opts[@]}"
		LOPPER_DTC_FLAGS="-b 0 -@" lopper -f --enhanced -O "$d/gen" \
			"$d/sdt/system-top.dts" "$d/gen/linux.dts" -- gen_domain_dts "$DT_PROC" linux_dt
		top=$d/gen/linux.dts
		;;
	*) die "DT_GEN은 dtg 또는 sdtgen 이어야 합니다: $DT_GEN" ;;
	esac
	[[ -f $top ]] || die "디바이스 트리 생성 결과가 없습니다: $(rel "$top")"

	# 생성물은 손대지 않고, 보드 고유 정보는 board.dtsi로 덮어쓴다
	printf '#include "%s"\n#include "%s"\n' "$top" "$TOP/board/board.dtsi" >"$d/system-board.dts"
	dt_cpp "$d/system.pp.dts" "$d/system-board.dts" \
		"$(dirname "$top")" "$(dirname "$top")/include" \
		"$SRC/linux-xlnx/include" "$SRC/linux-xlnx/scripts/dtc/include-prefixes" "$TOP/board"
	mkdir -p "$OUT"
	dtc -@ -I dts -O dtb -o "$OUT/system.dtb" "$d/system.pp.dts"
	dtc -q -I dtb -O dts -o "$d/system.dts" "$OUT/system.dtb"
	info "out/system.dtb ($(stat -c %s "$OUT/system.dtb") B) — 확인용 소스: $(rel "$d/system.dts")"
}

# ---------------------------------------------------------------------------
# uboot — U-Boot SPL(FSBL 대체) + U-Boot. ps7_init_gpl.c는 XSA에서 꺼낸 것
# ---------------------------------------------------------------------------
inputs_uboot() {
	h_vars UBOOT_DEFCONFIG UBOOT_DT_NAME CROSS_COMPILE
	h_file "$TOP/board/uboot.config" "$TOP/board/uboot.dtsi"
	h_git "$SRC/u-boot-xlnx"
}
outputs_uboot() { echo "$OUT/BOOT.BIN $OUT/u-boot.img"; }
stage_uboot() {
	need_cmd make bison flex "${CROSS_COMPILE}gcc"
	local src=$SRC/u-boot-xlnx d=$BUILD/uboot obj=$BUILD/uboot/obj dts
	rm -rf "$obj"
	mkdir -p "$obj/arch/arm/dts"

	# 생성 DTS를 빌드 디렉터리(obj) 쪽 arch/arm/dts에 둔다 — src/는 태그 그대로 유지.
	# U-Boot SPL은 bootph-* 표시가 있는 노드만 쓰므로 board/uboot.dtsi를 끝에 붙인다.
	dts=$obj/arch/arm/dts/$UBOOT_DT_NAME.dts
	{
		cat "$BUILD/dt/system.pp.dts"
		if [[ -f $TOP/board/uboot.dtsi ]]; then printf '\n#include "%s"\n' "$TOP/board/uboot.dtsi"; fi
	} >"$dts"

	cat >"$d/generated.config" <<-EOF
		CONFIG_XILINX_PS_INIT_FILE="$BUILD/hw/ps7_init_gpl.c"
		CONFIG_DEFAULT_DEVICE_TREE="$UBOOT_DT_NAME"
		CONFIG_OF_LIST="$UBOOT_DT_NAME"
		# CONFIG_OF_UPSTREAM is not set
	EOF

	umake() { make -C "$src" O="$obj" CROSS_COMPILE="$CROSS_COMPILE" "$@"; }
	umake -s "$UBOOT_DEFCONFIG"
	kconfig_merge "$src" "$obj" "$TOP/board/uboot.config" "$d/generated.config"
	umake -s olddefconfig
	kconfig_check 1 "$obj/.config" "$d/generated.config"
	kconfig_check 0 "$obj/.config" "$TOP/board/uboot.config"
	umake -j"$JOBS"

	mkdir -p "$OUT"
	install -m644 "$obj/spl/boot.bin" "$OUT/BOOT.BIN"
	install -m644 "$obj/u-boot.img" "$OUT/u-boot.img"
	info "out/BOOT.BIN (= spl/boot.bin), out/u-boot.img"
}

# ---------------------------------------------------------------------------
# kernel — linux-xlnx → zImage, modules.tar (XSA와 무관, 소스·설정이 같으면 재사용)
# ---------------------------------------------------------------------------
inputs_kernel() {
	h_vars LINUX_DEFCONFIG CROSS_COMPILE
	h_file "$TOP/board/kernel.config"
	h_git "$SRC/linux-xlnx"
}
outputs_kernel() { echo "$OUT/zImage $OUT/modules.tar"; }
stage_kernel() {
	need_cmd make bc bison flex depmod "${CROSS_COMPILE}gcc"
	local src=$SRC/linux-xlnx d=$BUILD/kernel obj=$BUILD/kernel/obj rel
	mkdir -p "$obj"   # obj는 지우지 않는다: 설정만 바뀌면 증분 빌드 (--clean이면 처음부터)
	kmake() { make -C "$src" O="$obj" ARCH=arm CROSS_COMPILE="$CROSS_COMPILE" "$@"; }

	kmake -s "$LINUX_DEFCONFIG"
	kconfig_merge "$src" "$obj" "$TOP/board/kernel.config"
	kmake -s olddefconfig
	kconfig_check 0 "$obj/.config" "$TOP/board/kernel.config"
	kmake -j"$JOBS" zImage modules
	rel=$(kmake -s kernelrelease)

	rm -rf "$d/modroot"
	kmake -s INSTALL_MOD_PATH="$d/modroot" INSTALL_MOD_STRIP=1 modules_install
	rm -f "$d/modroot/lib/modules/$rel/build" "$d/modroot/lib/modules/$rel/source"
	mkdir -p "$OUT"
	tar --owner=0 --group=0 --numeric-owner --mode=go-w -C "$d/modroot" -cf "$OUT/modules.tar" lib
	install -m644 "$obj/arch/arm/boot/zImage" "$OUT/zImage"
	echo "$rel" >"$d/kernelrelease"
	info "커널 $rel → out/zImage, out/modules.tar"
}

# ---------------------------------------------------------------------------
# rootfs — mmdebstrap (root 권한 불필요, qemu-user-static + binfmt 필요)
# ---------------------------------------------------------------------------
inputs_rootfs() {
	h_vars DISTRO SUITE MIRROR SECURITY_MIRROR COMPONENTS ROOTFS_ARCH PACKAGES EXTRA_PACKAGES \
		ROOTFS_KEYRING DEBIAN_KEYRING_URL TARGET_HOSTNAME TARGET_USER TARGET_PASSWORD \
		TARGET_PASSWORD_EXPIRE TIMEZONE LOCALE ROOT_DEV BOOT_DEV ROOT_GROW
	h_dir "$TOP/board/overlay"
	h_file "$TOP/scripts/rootfs-customize.sh"
}
outputs_rootfs() { echo "$OUT/rootfs.tar"; }

download() {   # download <URL> <파일> — 실패하면 1 (부분 파일은 남기지 않는다)
	mkdir -p "$(dirname "$2")"
	rm -f "$2.part"
	if command -v wget >/dev/null 2>&1; then
		wget -q -O "$2.part" "$1" || { rm -f "$2.part"; return 1; }
	else
		need_cmd curl
		curl -fsSL -o "$2.part" "$1" || { rm -f "$2.part"; return 1; }
	fi
	mv "$2.part" "$2"
}

rootfs_keyring() {   # mmdebstrap --keyring 에 줄 파일 경로
	local k deb tmp
	if [[ -n $ROOTFS_KEYRING ]]; then
		abspath "$ROOTFS_KEYRING"
		return
	fi
	case $DISTRO in
	ubuntu) echo /usr/share/keyrings/ubuntu-archive-keyring.gpg ;;
	debian)
		# Ubuntu 22.04의 debian-archive-keyring에는 trixie 서명 키가 없다 (계획서 5.6) → 최신 키링 사용
		k=$DL/debian-archive-keyring.gpg
		if [[ ! -f $k ]]; then
			deb=$DL/${DEBIAN_KEYRING_URL##*/}
			if [[ ! -f $deb ]]; then
				info "Debian 키링 받기: $DEBIAN_KEYRING_URL" >&2
				download "$DEBIAN_KEYRING_URL" "$deb" ||
					die "키링을 받지 못했습니다: $DEBIAN_KEYRING_URL
    packages.debian.org/trixie/all/debian-archive-keyring/download 에서 받아 dl/에 넣거나
    config.env의 ROOTFS_KEYRING= 에 키링(.gpg) 경로를 지정하세요."
			fi
			tmp=$(mktemp -d)
			dpkg-deb -x "$deb" "$tmp"
			install -m644 "$tmp/usr/share/keyrings/debian-archive-keyring.gpg" "$k"
			rm -rf "$tmp"
			info "키링: $(rel "$k")  (deb sha256 $(sha256sum <"$deb" | cut -c1-16)…)" >&2
		fi
		echo "$k"
		;;
	*) die "DISTRO는 debian 또는 ubuntu: $DISTRO" ;;
	esac
}

stage_rootfs() {
	need_cmd mmdebstrap dpkg-deb tar
	[[ $ROOTFS_ARCH == "$(dpkg --print-architecture)" ]] || need_cmd arch-test
	local d=$BUILD/rootfs keyring pkgs sources=()
	keyring=$(rootfs_keyring)
	[[ -f $keyring ]] || die "키링 파일이 없습니다: $keyring"
	# shellcheck disable=SC2086
	pkgs=$(printf '%s,' $PACKAGES $EXTRA_PACKAGES)
	sources=(
		"deb $MIRROR $SUITE $COMPONENTS"
		"deb $MIRROR $SUITE-updates $COMPONENTS"
		"deb $SECURITY_MIRROR $SUITE-security $COMPONENTS"
	)

	# 후처리 스크립트에 넘길 값 (mmdebstrap 훅은 별도 프로세스라 파일로 넘긴다)
	OVERLAY_DIR=$TOP/board/overlay
	declare -p OVERLAY_DIR TARGET_HOSTNAME TARGET_USER TARGET_PASSWORD TARGET_PASSWORD_EXPIRE \
		TIMEZONE LOCALE ROOT_DEV BOOT_DEV ROOT_GROW >"$d/customize.env"

	info "$DISTRO $SUITE $ROOTFS_ARCH — ${pkgs%,}"
	mmdebstrap \
		--architectures="$ROOTFS_ARCH" \
		--variant=minbase \
		--include="${pkgs%,}" \
		--keyring="$keyring" \
		--aptopt='Acquire::Retries "3"' \
		--customize-hook="bash '$TOP/scripts/rootfs-customize.sh' \"\$1\" '$d/customize.env'" \
		"$SUITE" "$d/rootfs.tar" "${sources[@]}"
	mkdir -p "$OUT"
	mv "$d/rootfs.tar" "$OUT/rootfs.tar"
	info "out/rootfs.tar ($(du -h "$OUT/rootfs.tar" | cut -f1))"
}

# ---------------------------------------------------------------------------
# image — boot.scr + FAT32(p1) + ext4(p2) → sdcard.img (root 권한 없이)
# ---------------------------------------------------------------------------
inputs_image() {
	h_vars SD_BOOT_MB SD_ROOT_MB ROOT_DEV
	h_file "$TOP/board/boot.cmd"
}
outputs_image() { echo "$OUT/sdcard.img $OUT/boot.scr"; }
stage_image() {
	need_cmd mkimage mkfs.vfat mcopy mke2fs sfdisk fakeroot tar
	local d=$BUILD/image root_mb used_mb p1 p2 files=() krel

	grep -q "root=$ROOT_DEV" "$TOP/board/boot.cmd" ||
		warn "board/boot.cmd의 root= 가 config.env의 ROOT_DEV($ROOT_DEV)와 다릅니다."
	mkimage -A arm -T script -C none -n "boot script" -d "$TOP/board/boot.cmd" "$OUT/boot.scr" >/dev/null

	# --- p1: FAT32 — BOOT.BIN, u-boot.img, boot.scr, zImage, system.dtb, system.bit
	files=("$OUT/BOOT.BIN" "$OUT/u-boot.img" "$OUT/boot.scr" "$OUT/zImage" "$OUT/system.dtb")
	if [[ -f $OUT/system.bit ]]; then files+=("$OUT/system.bit"); fi
	rm -f "$d/boot.vfat"
	mkfs.vfat -F 32 -n BOOT -C "$d/boot.vfat" $((SD_BOOT_MB * 1024)) >/dev/null
	mcopy -i "$d/boot.vfat" -o "${files[@]}" ::

	# --- p2: ext4 — rootfs.tar + modules.tar 를 fakeroot 안에서 풀어 소유자·권한을 지킨 채 mke2fs -d
	krel=$(tar -tf "$OUT/modules.tar" | awk -F/ '$1 == "lib" && $2 == "modules" && $3 != "" && k == "" { k = $3 } END { print k }')
	export IMG_DIR=$d IMG_OUT=$OUT SD_ROOT_MB
	# shellcheck disable=SC2016  # 아래 스크립트는 fakeroot 안의 bash가 해석한다
	fakeroot -- bash -euo pipefail -c '
		rm -rf "$IMG_DIR/root"
		mkdir "$IMG_DIR/root"
		tar -C "$IMG_DIR/root" -xpf "$IMG_OUT/rootfs.tar"
		# Debian/Ubuntu는 /lib → usr/lib 심볼릭 링크라 링크를 지키며 푼다
		tar -C "$IMG_DIR/root" --keep-directory-symlink -xpf "$IMG_OUT/modules.tar"
		used=$(du -s -B1M --apparent-size "$IMG_DIR/root" | cut -f1)
		if [[ $SD_ROOT_MB == auto ]]; then size=$(( (used * 5 / 4 + 256 + 3) / 4 * 4 )); else size=$SD_ROOT_MB; fi
		if (( used * 10 / 9 >= size )); then
			echo "오류: rootfs(${used} MiB)가 SD_ROOT_MB(${size} MiB)에 들어가지 않습니다" >&2
			exit 1
		fi
		echo "$used $size" >"$IMG_DIR/sizes"
		rm -f "$IMG_DIR/root.ext4"
		mke2fs -q -F -t ext4 -L rootfs -E root_owner=0:0 -d "$IMG_DIR/root" "$IMG_DIR/root.ext4" "${size}M"
	'
	read -r used_mb root_mb <"$d/sizes"
	rm -rf "$d/root"

	# --- 파티션 테이블(MBR) + 합치기. p1은 1 MiB에서 시작
	p1=1
	p2=$((1 + SD_BOOT_MB))
	rm -f "$d/sdcard.img"
	truncate -s $(((p2 + root_mb) * 1024 * 1024)) "$d/sdcard.img"
	sfdisk -q "$d/sdcard.img" <<-EOF
		label: dos
		unit: sectors
		1 : start=$((p1 * 2048)), size=$((SD_BOOT_MB * 2048)), type=c, bootable
		2 : start=$((p2 * 2048)), size=$((root_mb * 2048)), type=83
	EOF
	dd if="$d/boot.vfat" of="$d/sdcard.img" bs=1M seek=$p1 conv=notrunc,sparse status=none
	dd if="$d/root.ext4" of="$d/sdcard.img" bs=1M seek=$p2 conv=notrunc,sparse status=none
	mv "$d/sdcard.img" "$OUT/sdcard.img"
	rm -f "$d/root.ext4"

	write_buildinfo "$krel"
	info "out/sdcard.img: p1 FAT32 ${SD_BOOT_MB} MiB + p2 ext4 ${root_mb} MiB (rootfs ${used_mb} MiB, 커널 ${krel:-?})"
	sfdisk -l "$OUT/sdcard.img" | sed -n '/^Device/,$p'
}

write_buildinfo() {
	{
		echo "빌드 시각   $(date '+%F %T %z')"
		echo "호스트      $(hostname) / $(. /etc/os-release && echo "$PRETTY_NAME")"
		echo "XSA         $(rel "$(resolve_xsa)")  sha256 $(sha256sum <"$(resolve_xsa)" | cut -d' ' -f1)"
		echo "커널        ${1:-?}"
		echo "rootfs      $DISTRO $SUITE $ROOTFS_ARCH"
		echo "DT 생성     $DT_GEN"
		echo "소스:"
		sed 's/^/  /' "$BUILD/fetch/versions.txt" 2>/dev/null || true
		echo "산출물 sha256:"
		local f
		for f in BOOT.BIN u-boot.img boot.scr zImage system.dtb system.bit; do
			if [[ -f $OUT/$f ]]; then printf '  %s  %s\n' "$(sha256sum <"$OUT/$f" | cut -d' ' -f1)" "$f"; fi
		done
	} >"$OUT/buildinfo.txt"
}

# ===========================================================================
# 메인
# ===========================================================================
usage() { awk 'NR > 1 && /^# shellcheck/ { next } NR > 1 && /^#/ { sub(/^# ?/, ""); print; next } NR > 1 { exit }' "$0"; }

main() {
	local target=all a
	while (($#)); do
		a=$1
		shift
		case $a in
		--clean) CLEAN=1 ;;
		--xsa) XSA_CLI=${1:?--xsa 다음에 파일 경로}; shift ;;
		--xsa=*) XSA_CLI=${a#--xsa=} ;;
		-j) JOBS_CLI=${1:?-j 다음에 숫자}; shift ;;
		-j*) JOBS_CLI=${a#-j} ;;
		-h | --help) usage; exit 0 ;;
		-*) die "알 수 없는 옵션: $a (./build.sh --help)" ;;
		*) target=$a ;;
		esac
	done

	[[ $TOP != *[[:space:]]* ]] || die "폴더 경로에 공백이 있으면 안 됩니다: $TOP"
	load_config
	[[ -n ${XSA_CLI:-} ]] && XSA=$XSA_CLI
	JOBS=${JOBS_CLI:-${JOBS:-$(nproc)}}
	[[ -z ${XSA:-} || -f $(abspath "$XSA") ]] || die "XSA 파일이 없습니다: $XSA"

	case $target in
	status) show_status; return ;;
	clean) rm -rf "$BUILD" "$OUT"; info "build/ out/ 삭제"; return ;;
	distclean) rm -rf "$BUILD" "$OUT" "$SRC"; info "build/ out/ src/ 삭제"; return ;;
	all) target=image ;;
	esac
	is_stage "$target" || die "알 수 없는 단계: $target (./build.sh --help)"

	mkdir -p "$BUILD" "$LOGDIR"
	exec 9>"$BUILD/.lock"
	flock -n 9 || die "다른 build.sh가 이 폴더에서 실행 중입니다."

	run_stage "$target"

	if [[ $target == image ]]; then
		info "완료. SD 카드에 쓰기 (sdX는 lsblk로 확인):"
		echo "    sudo dd if=$(rel "$OUT/sdcard.img") of=/dev/sdX bs=4M conv=fsync status=progress"
	fi
}

main "$@"
