# z7015-linux

시스템 1 수신부(Zynq-7015)용 Linux SD 카드 이미지 빌드 묶음. `z7015_linux_plan.md`를 그대로 스크립트로 옮겼다.

```
hw/*.xsa ──▶ ./build.sh ──▶ out/sdcard.img
```

부팅 체인: **U-Boot SPL(FSBL 대체) → U-Boot → Linux(linux-xlnx 6.12)**, rootfs: **Debian 13 trixie armhf** (Ubuntu 24.04로 전환 가능)

---

## 1. 빠른 시작

```bash
# 0) 처음 한 번: 실행 권한 (복사 과정에서 빠졌을 수 있음 — 'bash build.sh' 나 'make'는 권한 없이도 된다)
chmod +x build.sh

# 1) XSA 넣기 (Vivado: File > Export > Export Hardware > Include bitstream)
cp ~/vivado/z7015/design_1_wrapper.xsa hw/

# 2) 빌드 — 필요한 단계만 자동으로 판단해 실행
./build.sh            # = ./build.sh all = make

# 3) SD 카드에 쓰기 (sdX는 lsblk로 확인)
sudo dd if=out/sdcard.img of=/dev/sdX bs=4M conv=fsync status=progress
```

- UART 115200 8N1. 로그인 **zynq / zynq** (첫 로그인 때 비밀번호를 바꾸게 한다). SSH, DHCP가 켜져 있다.
- 첫 부팅 때 p2(rootfs)를 SD 카드 끝까지 늘리고 SSH 호스트 키를 만든다.
- 첫 빌드는 소스 받기 + 커널 + rootfs 때문에 오래 걸린다. 이후 XSA만 바꾸면 hw → dt → uboot → image만 다시 돈다.

## 2. 빌드 호스트 준비 (Ubuntu 22.04.5, 계획서 9장)

```bash
sudo apt install git build-essential bc bison flex libssl-dev libgnutls28-dev \
  python3 python3-dev python3-setuptools swig device-tree-compiler u-boot-tools \
  gcc-arm-linux-gnueabihf mmdebstrap qemu-user-static binfmt-support arch-test \
  dosfstools mtools e2fsprogs fdisk xz-utils unzip fakeroot kmod wget
```

- 계획서 목록에 **arch-test**(mmdebstrap이 armhf 실행 가능 여부 확인), **fakeroot**(root 없이 이미지 만들 때 소유권 보존), **kmod**·**wget**을 더했다.
- Vitis 2025.2: `xsct`(DTG) 또는 `sdtgen`이 필요하다. `/tools/Xilinx/2025.2/Vitis/settings64.sh` 등을 자동으로 찾고,
  다른 곳에 설치했다면 `config.local.env`에 `XILINX_SETTINGS=/경로/settings64.sh`를 적는다.
  settings64.sh는 dt 단계 안에서만 불러 다른 단계의 PATH를 어지럽히지 않는다.
- rootfs는 root 권한 없이(mmdebstrap unshare 모드) 만든다. `/etc/subuid`·`/etc/subgid`에 사용자 항목이 있어야 한다 (adduser로 만든 계정이면 기본으로 있음).

## 3. build.sh

```
./build.sh [all|fetch|hw|dt|uboot|kernel|rootfs|image] [--clean] [--xsa 파일] [-j N]
./build.sh status       # 단계별 상태 (최신 / 입력 변경 / 산출물 없음 / 빌드 안 됨)
./build.sh clean        # build/ out/ 삭제 (src/ dl/ 유지)
./build.sh distclean    # src/ 까지 삭제
make uboot CLEAN=1      # Makefile은 build.sh 래퍼
```

| 단계 | 입력 | 출력 | 다시 도는 조건 |
|---|---|---|---|
| fetch | 태그 3종 | `src/` (얕은 클론) | 최초 1회, 태그 변경 |
| hw | XSA | `build/hw/ps7_init_gpl.c/h`, `out/system.bit` | XSA 내용(sha256) 변경 |
| dt | hw, `board/board.dtsi` | `out/system.dtb`, `build/dt/system.pp.dts` | hw·board.dtsi·DT_GEN 변경 |
| uboot | hw, dt, `board/uboot.config`, `board/uboot.dtsi` | `out/BOOT.BIN`, `out/u-boot.img` | 위 입력·U-Boot 소스 변경 |
| kernel | linux-xlnx, `board/kernel.config` | `out/zImage`, `out/modules.tar` | 소스(커밋·로컬 수정)·설정 변경 |
| rootfs | `config.env` 배포판 항목, `board/overlay/` | `out/rootfs.tar` | 배포판 설정·overlay 변경 |
| image | 위 산출물, `board/boot.cmd` | `out/boot.scr`, `out/sdcard.img` | 위 중 하나라도 변경 |

- 변경 감지는 파일 수정 시각이 아니라 입력의 sha256을 `build/<단계>/.hash`에 저장해 비교한다. 단계 스크립트 자체가 바뀌어도 다시 돈다.
- `./build.sh uboot`처럼 단계를 지정하면 앞 단계가 오래됐을 때 같이 돈다.
- `--clean`은 이번에 실행하는 단계들의 캐시를 지우고 처음부터 만든다 (`./build.sh kernel --clean` → 커널 전체 재빌드).
- 단계별 로그: `build/logs/<단계>.log`. 소스 버전: `build/fetch/versions.txt`. 산출물 해시: `out/buildinfo.txt`.
- rootfs는 패키지 갱신을 따라가지 않는다(캐시 재사용). 최신 패키지로 다시 만들려면 `./build.sh rootfs --clean`.

## 4. 디렉터리

```
z7015-linux/
├── build.sh  Makefile  config.env      (config.local.env — PC별 설정, Git 제외)
├── hw/                 # XSA
├── board/              # 손으로 관리 (Git)
│   ├── board.dtsi      # 보드 고유 DT 덮어쓰기 (PHY, SD CD/WP, QSPI, LED·버튼, chosen)
│   ├── uboot.dtsi      # U-Boot 전용 DT 추가분 (SPL용 bootph-all)
│   ├── uboot.config    # U-Boot 설정 조각
│   ├── kernel.config   # 커널 설정 조각 (systemd 필수 옵션)
│   ├── boot.cmd        # U-Boot 부팅 스크립트
│   └── overlay/        # rootfs에 덮어쓸 파일 (networkd, 첫 부팅 서비스)
├── scripts/            # lib.sh(공통), dtg.tcl(xsct), rootfs-customize.sh(mmdebstrap 훅)
├── src/                # u-boot-xlnx, linux-xlnx, device-tree-xlnx (태그 고정)
├── dl/                 # 내려받은 파일 (Debian 키링)
├── build/<단계>/       # 작업 디렉터리 + .hash, build/logs/
└── out/                # BOOT.BIN u-boot.img boot.scr zImage system.dtb system.bit
                        # modules.tar rootfs.tar sdcard.img buildinfo.txt
```

SD 카드 구성 (계획서 5.7):

| 파티션 | 형식 | 크기 | 내용 |
|---|---|---|---|
| p1 | FAT32 `BOOT` | `SD_BOOT_MB` (256 MiB) | BOOT.BIN, u-boot.img, boot.scr, zImage, system.dtb, system.bit |
| p2 | ext4 `rootfs` | rootfs + 여유분 → 첫 부팅 때 카드 끝까지 | rootfs + `/lib/modules` |

## 5. 처음 맞춰야 할 것

1. **board/board.dtsi** — 이더넷 PHY 주소·phy-mode, SD 카드 CD/WP, QSPI, LED·버튼. 예시가 주석으로 들어 있다.
   보드 회로도와 벤더 BSP의 DTS를 보고 채운다. 최종 결과는 `build/dt/system.dts`에서 확인한다.
2. **board/uboot.dtsi** — 콘솔 UART·SD가 `uart0/uart1`, `sdhci0/sdhci1` 밖이면 추가한다.
3. **config.env** — 사용자·비밀번호·호스트 이름·시간대, `ROOT_DEV`(= boot.cmd의 `root=`).
4. M1(U-Boot 프롬프트)은 board.dtsi 없이도 된다. `./build.sh image` 후 UART에 SPL → U-Boot 로그가 나오는지부터 본다.

## 6. 계획서와 다른 점 / 확인해서 보완한 점

계획서 5.4의 "첫 빌드에서 확인할 것"은 u-boot-xlnx `xilinx-v2025.2`를 실제로 빌드해 확인했다.

| 항목 | 내용 |
|---|---|
| OF_UPSTREAM | `xilinx_zynq_virt_defconfig`에서 꺼져 있음(zynq 기본값). 생성 조각에서 한 번 더 끈다. |
| bootph 태그 | **필요하다.** DTG 출력에는 없어서 SPL DTB에 `/chosen`만 남는다. `board/uboot.dtsi`로 amba·slcr·clkc·scutimer·UART·SD·QSPI에 `bootph-all`을 붙인다. |
| U-Boot DTS 위치 | `src/u-boot-xlnx`에 넣지 않고 빌드 디렉터리(`build/uboot/obj/arch/arm/dts/`)에 둔다. src/는 태그 그대로 유지된다. |
| U-Boot DT 지정 | `CONFIG_DEFAULT_DEVICE_TREE`와 `CONFIG_OF_LIST`를 생성 DTS 하나로. u-boot.img(FIT)에 이 DTB만 들어간다. |
| SPL falcon 모드 | 기본값은 SPL이 FAT의 uImage를 먼저 찾는다. `board/uboot.config`에서 꺼 SPL → U-Boot → Linux로 고정했다. |
| 비트스트림 주소 | 이 U-Boot의 `loadaddr` 기본값이 0x0(OCM과 겹칠 수 있음)이라 boot.cmd는 `bit_addr_r=0x06000000`을 쓴다. |
| 이미지 소유권 | `mke2fs -d`가 rootfs.tar의 root 소유·장치 파일·setuid를 지키도록 압축 해제와 mke2fs를 **fakeroot** 안에서 한다. |
| Debian 키링 | Ubuntu 22.04 호스트 키링에는 trixie 서명 키가 없다. `debian-archive-keyring_2025.1`을 받아 `dl/`에 두고 `--keyring`으로 쓴다. |
| apt 저장소 | 기본 저장소에 `-updates`, `-security`를 더했다. |
| 네트워크 | systemd v251+는 DT 보드의 eth0을 `end0`으로 부르므로 `.network`가 `eth* en*`을 모두 잡는다. 케이블이 없을 때 부팅이 멈추지 않도록 `systemd-networkd-wait-online`은 끈다. |
| 첫 부팅 | SSH 호스트 키를 보드마다 만들고(이미지에 넣지 않음), p2를 카드 끝까지 늘린다(`ROOT_GROW=1`). |

## 7. 시험한 범위

클라우드 환경(Ubuntu 24.04, 2코어)에서 일반 사용자 권한으로 아래를 실제로 돌려 확인했다. Vivado와 보드는 없다.

- **fetch**: 세 저장소의 2025.2 태그 확인·얕은 클론, 이미 있는 소스 재사용
- **hw → dt → uboot**: 가짜 XSA(ps7_init_gpl.c/h + .bit)와 DTG 형식의 생성물로 SPL(`BOOT.BIN`)·`u-boot.img` 빌드(약 1분).
  SPL DTB에 UART·SD·QSPI 노드가 남는지, u-boot.img(FIT)에 생성 DTB 하나만 들어가는지 확인
- **kernel**: linux-xlnx `xilinx-v2025.2` + `kernel.config` → zImage, modules.tar (2코어 12분, 설정만 바뀌면 증분 15초)
- **image**: fakeroot + mke2fs -d로 소유권(0:0)·setuid·`/tmp` 1777 보존, MBR 파티션, e2fsck 통과
- **QEMU(xilinx-zynq-a9) 부팅**: 이 빌드의 U-Boot → SD에서 `boot.scr` 실행 → zImage·system.dtb 로드 → 커널 6.12 →
  `/dev/mmcblk0p2` 루트 마운트 → init 실행까지. `/lib/modules/<커널>` · hostname · fstab · 첫 부팅 서비스 배치 확인
  (QEMU에는 FPGA가 없어 `fpga loadb`만 실패하고 다음 단계로 넘어간다)
- **변경 감지**: board.dtsi 변경 → dt·uboot·image만, `--clean` → 지정한 단계와 앞 단계만

확인하지 못한 것: 실제 xsct(DTG)/sdtgen 실행, 실제 Debian 미러로 mmdebstrap(시험에서는 대역 스크립트로 훅만 실행),
SPL 단계(QEMU는 BootROM이 없어 U-Boot부터 시작), 실제 Z7015 보드 부팅, 첫 부팅 파티션 확장.
첫 실제 빌드에서 dt·rootfs 단계 로그(`build/logs/`)를 한 번 확인한다.

## 8. 문제 해결

| 증상 | 확인할 것 |
|---|---|
| SPL이 `mmc init failed` / U-Boot가 SD를 못 찾음 | SD CD 핀이 PS에 연결 안 됨 → board.dtsi의 `&sdhci0 { broken-cd; disable-wp; };` |
| UART에 아무것도 안 나옴 | 콘솔 UART가 uart0인지 uart1인지 (XSA의 PS 설정, `serial0` alias), DDR 설정(ps7_init) |
| dt 단계: xsct를 찾을 수 없음 | `config.local.env`의 `XILINX_SETTINGS`, 또는 `DT_GEN=sdtgen` (lopper 필요: `pip3 install --user lopper`) |
| rootfs: `arch-test`·`exec format error` | `qemu-user-static`, `binfmt-support` 설치 후 재부팅 또는 `systemctl restart binfmt-support` |
| rootfs: unshare 실패 | `/etc/subuid`·`/etc/subgid`에 사용자 항목, `sysctl kernel.unprivileged_userns_clone=1` |
| rootfs: 서명 확인 실패 | `dl/debian-archive-keyring.gpg` 삭제 후 다시 실행, 또는 `ROOTFS_KEYRING=` 지정 |
| 호스트가 PCIe 장치를 못 봄 (M4) | PL이 FSBL 방식보다 늦게 올라온다 (계획서 6장). 호스트에서 `echo 1 \| sudo tee /sys/bus/pci/rescan` |
