# DTG(device-tree-xlnx)로 XSA에서 디바이스 트리 소스를 만든다.
# 사용: xsct dtg.tcl <xsa> <device-tree-xlnx> <출력 디렉터리> <프로세서> <보드|-> <오버레이 0|1> <펌웨어 이름|->
#   프로세서 : ps7_cortexa9_0 (Zynq-7000), psu_cortexa53_0 (ZynqMP)
#   보드     : device-tree-xlnx/device_tree/data/kernel_dtsi/<버전>/BOARD 아래 이름 (예: zcu104-revc). 없으면 -
#   오버레이 : 1이면 PL 부분만 오버레이(pl.dtsi)로 만든다 (런타임 PL 로드용)
#   펌웨어   : 오버레이의 firmware-name 기본값 (.bin이 붙는다). 없으면 -
# AMD 위키 "Build Device Tree Blob"의 XSCT 절차를 그대로 따른다.

if {[llength $argv] != 7} {
	puts stderr "usage: xsct dtg.tcl <xsa> <dtg_repo> <outdir> <proc> <board|-> <overlay 0|1> <fwname|->"
	exit 2
}
lassign $argv xsa repo outdir proc board overlay fwname

if {[catch {
	hsi open_hw_design $xsa
	hsi set_repo_path $repo

	set procs [hsi get_cells -hier -filter {IP_TYPE==PROCESSOR}]
	puts "INFO: processors in XSA: $procs"
	if {[lsearch -exact $procs $proc] < 0} {
		error "processor $proc not found in XSA (found: $procs)"
	}

	hsi create_sw_design device-tree -os device_tree -proc $proc
	if {$board ne "-"} {
		hsi set_property CONFIG.periph_type_overrides "{BOARD $board}" [hsi get_os]
	}
	if {$overlay eq "1"} {
		hsi set_property CONFIG.dt_overlay true [hsi get_os]
	}
	if {$fwname ne "-"} {
		hsi set_property CONFIG.firmware_name $fwname [hsi get_os]
	}
	hsi generate_target -dir $outdir
	hsi close_hw_design [hsi current_hw_design]
} err]} {
	puts stderr "ERROR: DTG failed: $err"
	exit 1
}
exit 0
