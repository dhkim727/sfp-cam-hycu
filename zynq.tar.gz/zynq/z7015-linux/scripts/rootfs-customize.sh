#!/bin/bash
# rootfs 후처리 — mmdebstrap --customize-hook 에서 실행된다 (계획서 5.6).
#   $1 = 만들고 있는 rootfs(chroot) 디렉터리
#   $2 = build/rootfs/customize.env (build.sh가 config.env 값을 넘겨 준다)
# chroot 안의 armhf 프로그램은 qemu-user-static(binfmt)으로 실행된다.
set -euo pipefail
R=$1
# shellcheck disable=SC1090
source "$2"
umask 022

in_chroot() { chroot "$R" "$@"; }
enable_unit() { in_chroot systemctl enable "$@"; }

echo "rootfs 후처리: $R"

# 1) board/overlay → / : 파일·링크만 root 소유로 복사, 그룹/기타 쓰기 권한은 뺀다
if [[ -d $OVERLAY_DIR ]]; then
	(cd "$OVERLAY_DIR" && find . \( -type f -o -type l \) ! -name .gitkeep -print0 |
		tar --null --no-recursion -T - --owner=0 --group=0 --numeric-owner --mode=go-w -cf -) |
		tar -C "$R" --keep-directory-symlink -xpf -
	# 복사 과정에서 실행 권한이 빠졌을 수 있으니 sbin/bin 아래는 755로 맞춘다
	for f in "$R"/usr/local/sbin/* "$R"/usr/local/bin/*; do
		if [[ -f $f ]]; then chmod 0755 "$f"; fi
	done
fi

# 2) 호스트 이름 (mmdebstrap이 복사해 둔 빌드 호스트 값을 덮어쓴다)
echo "$TARGET_HOSTNAME" >"$R/etc/hostname"
cat >"$R/etc/hosts" <<EOF
127.0.0.1	localhost
127.0.1.1	$TARGET_HOSTNAME
::1		localhost ip6-localhost ip6-loopback
ff02::1		ip6-allnodes
ff02::2		ip6-allrouters
EOF

# 3) fstab — root = p2, FAT(p1)은 /boot/firmware
mkdir -p "$R/boot/firmware"
cat >"$R/etc/fstab" <<EOF
# <장치>          <마운트 위치>    <형식> <옵션>                   <dump> <fsck>
$ROOT_DEV  /               ext4   defaults,noatime          0      1
$BOOT_DEV  /boot/firmware  vfat   defaults,noatime,nofail   0      2
EOF

# 4) 사용자 + sudo
if ! in_chroot id -u "$TARGET_USER" >/dev/null 2>&1; then
	in_chroot useradd -m -s /bin/bash -G sudo,adm "$TARGET_USER"
fi
printf '%s:%s\n' "$TARGET_USER" "$TARGET_PASSWORD" | in_chroot chpasswd
if [[ $TARGET_PASSWORD_EXPIRE == 1 ]]; then
	in_chroot passwd -e "$TARGET_USER" >/dev/null   # 첫 로그인 때 비밀번호 변경
fi

# 5) 시간대·로캘
mkdir -p "$R/etc/default"
ln -sf "/usr/share/zoneinfo/$TIMEZONE" "$R/etc/localtime"
echo "$TIMEZONE" >"$R/etc/timezone"
echo "LANG=$LOCALE" >"$R/etc/default/locale"

# 6) 네트워크: systemd-networkd(.network 파일은 overlay) + resolved
enable_unit systemd-networkd.service systemd-resolved.service
# 케이블이 없을 때 부팅이 2분씩 멈추지 않도록 wait-online은 끈다
in_chroot systemctl disable systemd-networkd-wait-online.service >/dev/null 2>&1 || true
rm -f "$R/etc/resolv.conf"
ln -s ../run/systemd/resolve/stub-resolv.conf "$R/etc/resolv.conf"

# 7) SSH: 호스트 키는 보드마다 첫 부팅 때 만든다 (이미지에 넣으면 모든 보드가 같은 키를 갖게 됨)
rm -f "$R"/etc/ssh/ssh_host_*
if [[ -f $R/etc/systemd/system/ssh-host-keygen.service ]]; then
	enable_unit ssh-host-keygen.service
fi

# 8) 첫 부팅 때 p2를 SD 카드 끝까지 확장
if [[ $ROOT_GROW == 1 && -f $R/etc/systemd/system/grow-rootfs.service ]]; then
	enable_unit grow-rootfs.service
	touch "$R/etc/grow-rootfs.enable"
fi

# 시리얼 콘솔은 커널 인자 console=ttyPS0,115200 이 있으면 systemd가 serial-getty를 자동으로 띄운다
echo "rootfs 후처리 끝"
