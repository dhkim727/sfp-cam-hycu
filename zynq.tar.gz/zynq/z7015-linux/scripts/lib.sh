# shellcheck shell=bash
# 빌드 공통 함수 — build.sh가 source 한다.
# z7015-linux / zcu104-linux 두 폴더에 같은 내용으로 들어 있다. 고칠 때는 둘 다 고친다.
#
# build.sh가 먼저 정해 두는 변수: TOP BUILD OUT SRC DL LOGDIR

# ---------------------------------------------------------------------------
# 출력
# ---------------------------------------------------------------------------
info() { printf '==> %s\n' "$*"; }
warn() { printf '경고: %s\n' "$*" >&2; }
die()  { printf '오류: %s\n' "$*" >&2; exit 1; }
rel()  { printf '%s' "${1#"$TOP"/}"; }          # 로그용 상대 경로

on_err() {
	local rc=$1 line=$2 cmd=$3
	printf '오류: 명령 실패 (exit %s, %s:%s): %s\n' "$rc" "$(basename "${BASH_SOURCE[1]:-build.sh}")" "$line" "$cmd" >&2
}

need_cmd() {   # need_cmd 명령... — 없으면 설치 안내와 함께 중단
	local c miss=()
	for c; do command -v "$c" >/dev/null 2>&1 || miss+=("$c"); done
	((${#miss[@]} == 0)) && return 0
	die "필요한 명령이 없습니다: ${miss[*]}
    README.md의 '빌드 호스트 준비' 패키지를 설치하세요."
}

# ---------------------------------------------------------------------------
# 설정
# ---------------------------------------------------------------------------
load_config() {   # config.env → config.local.env(있으면, Git 제외용) 순서로 읽는다
	local f
	for f in "$TOP/config.env" "$TOP/config.local.env"; do
		[[ -f $f ]] || continue
		# shellcheck disable=SC1090
		source "$f"
	done
}

abspath() {   # TOP 기준 상대 경로를 절대 경로로
	case $1 in
	/*) printf '%s' "$1" ;;
	'') printf '' ;;
	*) printf '%s/%s' "$TOP" "$1" ;;
	esac
}

# XSA 자동 선택: --xsa / config.env XSA= → hw/system.xsa → hw/에 .xsa가 하나뿐이면 그것
resolve_xsa() {
	local p f=()
	if [[ -n ${XSA:-} ]]; then
		p=$(abspath "$XSA")
		[[ -f $p ]] || die "XSA 파일이 없습니다: $p"
		printf '%s' "$p"
		return
	fi
	if [[ -f $TOP/hw/system.xsa ]]; then
		printf '%s' "$TOP/hw/system.xsa"
		return
	fi
	shopt -s nullglob
	f=("$TOP"/hw/*.xsa)
	shopt -u nullglob
	((${#f[@]} > 0)) || die "hw/ 폴더에 XSA가 없습니다.
    Vivado에서 File > Export > Export Hardware (Include bitstream)로 만든 .xsa를 hw/에 넣으세요."
	((${#f[@]} == 1)) || die "hw/에 XSA가 여러 개입니다: ${f[*]##*/}
    config.env의 XSA= 또는 ./build.sh --xsa <파일> 로 하나를 고르세요."
	printf '%s' "${f[0]}"
}

# ---------------------------------------------------------------------------
# 변경 감지용 해시 재료 (출력 줄들을 모아 sha256을 만든다)
# ---------------------------------------------------------------------------
h_vars() { local v; for v; do printf 'var %s=%s\n' "$v" "${!v-}"; done; }

h_file() {
	local f
	for f; do
		if [[ -f $f ]]; then
			printf 'file %s %s\n' "$(rel "$f")" "$(sha256sum <"$f" | cut -d' ' -f1)"
		else
			printf 'file %s (없음)\n' "$(rel "$f")"
		fi
	done
}

h_dir() {   # 디렉터리 안 파일 내용 + 심볼릭 링크 대상
	local d=$1 p
	if [[ ! -d $d ]]; then
		printf 'dir %s (없음)\n' "$(rel "$d")"
		return
	fi
	(
		cd "$d" || exit 1
		find . \( -type f -o -type l \) ! -name .gitkeep -print0 | LC_ALL=C sort -z |
			while IFS= read -r -d '' p; do
				if [[ -L $p ]]; then
					printf 'link %s -> %s\n' "$p" "$(readlink "$p")"
				else
					printf 'f %s %s\n' "$p" "$(sha256sum <"$p" | cut -d' ' -f1)"
				fi
			done
	)
}

h_git() {   # 커밋 + 로컬 수정(diff) + 추적 안 되는 파일까지 반영
	local d=$1
	if [[ ! -e $d/.git ]]; then
		printf 'git %s (없음)\n' "$(rel "$d")"
		return
	fi
	printf 'git %s %s diff=%s new=%s\n' "$(rel "$d")" \
		"$(git -C "$d" rev-parse HEAD 2>/dev/null || echo none)" \
		"$(git -C "$d" diff HEAD --binary 2>/dev/null | sha256sum | cut -d' ' -f1)" \
		"$(cd "$d" && git ls-files -z --others --exclude-standard | xargs -0 -r sha256sum | sha256sum | cut -d' ' -f1)"
}

# ---------------------------------------------------------------------------
# 단계 엔진
#   stage <이름> "<해시에 반영되는 선행 단계>" "<순서만 필요한 선행 단계>"
#   단계마다 stage_<이름>(실행), inputs_<이름>(해시 재료 출력), outputs_<이름>(산출물 경로)
# ---------------------------------------------------------------------------
declare -A STAGE_DEPS=() STAGE_AFTER=() STAGE_DONE=() STAGE_HASH=()
STAGES=()
CLEAN=0

stage() {
	STAGES+=("$1")
	STAGE_DEPS[$1]=${2:-}
	STAGE_AFTER[$1]=${3:-}
}

is_stage() {
	local s
	for s in "${STAGES[@]}"; do [[ $s == "$1" ]] && return 0; done
	return 1
}

calc_hash() {   # 입력 해시를 STAGE_HASH[단계]에 계산해 둔다 (선행 단계 해시 포함, 재귀)
	local s=$1 d
	[[ -n ${STAGE_HASH[$s]:-} ]] && return 0
	for d in ${STAGE_DEPS[$s]}; do calc_hash "$d"; done
	STAGE_HASH[$s]=$(
		{
			printf 'stage %s\n' "$s"
			declare -f "stage_$s" "inputs_$s"   # 단계 코드가 바뀌어도 다시 돈다
			for d in ${STAGE_DEPS[$s]}; do printf 'dep %s %s\n' "$d" "${STAGE_HASH[$d]}"; done
			"inputs_$s"
		} | sha256sum | cut -d' ' -f1
	)
}

missing_outputs() {   # 없는 산출물 경로를 출력
	local f
	for f in $("outputs_$1"); do [[ -e $f ]] || printf '%s\n' "$f"; done
}

STATE=''
stage_state() {   # STATE ← 최신 | 입력 변경 | 산출물 없음 | 빌드 안 됨
	local s=$1 have=''
	calc_hash "$s"
	[[ -f $BUILD/$s/.hash ]] && have=$(<"$BUILD/$s/.hash")
	if [[ -z $have ]]; then
		STATE="빌드 안 됨"
	elif [[ ${STAGE_HASH[$s]} != "$have" ]]; then
		STATE="입력 변경"
	elif [[ -n $(missing_outputs "$s") ]]; then
		STATE="산출물 없음"
	else
		STATE="최신"
	fi
}

run_stage() {
	local s=$1 d st t0 rc
	[[ -n ${STAGE_DONE[$s]:-} ]] && return 0
	for d in ${STAGE_DEPS[$s]} ${STAGE_AFTER[$s]}; do run_stage "$d"; done

	unset 'STAGE_HASH[$s]'   # 선행 단계가 방금 돌았을 수 있으니 다시 계산
	stage_state "$s"
	st=$STATE
	if ((CLEAN == 0)) && [[ $st == 최신 ]]; then
		info "[$s] 최신 — 건너뜀"
		STAGE_DONE[$s]=1
		return 0
	fi
	((CLEAN)) && st="--clean"
	info "[$s] 시작 ($st)"
	((CLEAN)) && rm -rf "${BUILD:?}/$s"
	mkdir -p "$BUILD/$s" "$LOGDIR"
	rm -f "$BUILD/$s/.hash"

	t0=$SECONDS
	# 주의: 이 파이프라인을 '|| ...' 나 'if' 안에 넣으면 bash가 하위 셸의 set -e까지 무시한다.
	# 그래서 set +e로 감싸고 PIPESTATUS로 결과를 본다.
	set +e
	trap - ERR
	(
		set -Eeuo pipefail
		trap 'on_err $? $LINENO "$BASH_COMMAND"' ERR
		"stage_$s"
	) 2>&1 | tee "$LOGDIR/$s.log"
	rc=${PIPESTATUS[0]}
	trap 'on_err $? $LINENO "$BASH_COMMAND"' ERR
	set -e
	((rc == 0)) || die "[$s] 단계 실패 (exit $rc) — 로그: $(rel "$LOGDIR/$s.log")"

	local miss
	miss=$(missing_outputs "$s")
	[[ -z $miss ]] || die "[$s] 끝났지만 산출물이 없습니다: $miss"
	printf '%s\n' "${STAGE_HASH[$s]}" >"$BUILD/$s/.hash"
	STAGE_DONE[$s]=1
	info "[$s] 완료 ($((SECONDS - t0))초)"
}

show_status() {
	local s
	printf '단계     상태\n'
	for s in "${STAGES[@]}"; do
		stage_state "$s"
		printf '%-8s %s\n' "$s" "$STATE"
	done
}

# ---------------------------------------------------------------------------
# 소스 가져오기 (태그 고정, 얕은 클론)
# ---------------------------------------------------------------------------
# git_fetch_tag <이름> <URL> <태그> <디렉터리>
git_fetch_tag() {
	local name=$1 url=$2 tag=$3 dir=$4 alt cur tags
	if [[ -e $dir/.git ]]; then
		cur=$(git -C "$dir" describe --tags --exact-match HEAD 2>/dev/null || true)
		if [[ $cur == "$tag" ]]; then
			info "$name: $tag (이미 있음)"
			return 0
		fi
	fi

	# 원격 태그 목록으로 존재를 먼저 확인한다 (계획서 2장)
	if ! tags=$(git ls-remote --tags --refs "$url" 2>&1); then
		die "$name: 원격 저장소에 접속할 수 없습니다 ($url)
$tags"
	fi
	# shellcheck disable=SC2001  # 여러 줄이라 sed가 맞다
	tags=$(sed 's#.*refs/tags/##' <<<"$tags")
	if ! grep -qxF "$tag" <<<"$tags"; then
		# 저장소마다 xilinx-v / xilinx_v 표기가 다르다
		case $tag in
		*-v*) alt=${tag/-v/_v} ;;
		*_v*) alt=${tag/_v/-v} ;;
		*) alt= ;;
		esac
		if [[ -n $alt ]] && grep -qxF "$alt" <<<"$tags"; then
			warn "$name: 태그 '$tag'가 없어 '$alt'를 씁니다. config.env의 표기를 고쳐 두세요."
			tag=$alt
		else
			die "$name: 원격 저장소에 태그 '$tag'가 없습니다 ($url)
    최근 태그: $(grep -E '20[0-9]{2}\.[0-9]' <<<"$tags" | LC_ALL=C sort -V | tail -6 | tr '\n' ' ')"
		fi
	fi

	if [[ -e $dir/.git ]]; then
		[[ -z $(git -C "$dir" status --porcelain --untracked-files=no) ]] ||
			die "$name: $(rel "$dir")에 로컬 수정이 있어 태그를 바꿀 수 없습니다 (현재 ${cur:-?}). 커밋/정리 후 다시 실행하세요."
		info "$name: ${cur:-?} → $tag 전환"
		git -C "$dir" fetch -q --depth 1 origin "refs/tags/$tag:refs/tags/$tag"
		git -C "$dir" -c advice.detachedHead=false checkout -q "refs/tags/$tag"
	else
		info "$name: $tag 클론 ($url)"
		rm -rf "$dir"
		git -c advice.detachedHead=false clone -q --depth 1 --branch "$tag" "$url" "$dir"
	fi
	info "$name: $(git -C "$dir" describe --tags 2>/dev/null || git -C "$dir" rev-parse --short HEAD)"
}

# ---------------------------------------------------------------------------
# Vivado / Vitis 환경
# ---------------------------------------------------------------------------
xilinx_settings() {   # settings64.sh 경로 (없으면 빈 문자열)
	local v=${XILINX_VERSION:-2025.2} c base
	if [[ -n ${XILINX_SETTINGS:-} ]]; then
		[[ -f $XILINX_SETTINGS ]] || die "XILINX_SETTINGS 파일이 없습니다: $XILINX_SETTINGS"
		printf '%s' "$XILINX_SETTINGS"
		return
	fi
	for base in /tools/Xilinx /opt/Xilinx "$HOME/Xilinx" /tools/AMD /opt/AMD; do
		for c in "$base/$v/Vitis" "$base/Vitis/$v" "$base/$v/Vivado" "$base/Vivado/$v"; do
			if [[ -f $c/settings64.sh ]]; then
				printf '%s' "$c/settings64.sh"
				return
			fi
		done
	done
}

xrun() {   # xrun <명령> [인자...] — Vivado/Vitis 환경을 불러 하위 셸에서 실행
	local s
	s=$(xilinx_settings)
	if [[ -z $s ]]; then
		command -v "$1" >/dev/null 2>&1 ||
			die "$1 을(를) 찾을 수 없습니다. config.env의 XILINX_SETTINGS에 Vitis ${XILINX_VERSION:-2025.2}의 settings64.sh 경로를 넣으세요."
		"$@"
		return
	fi
	(
		set +eu
		# shellcheck disable=SC1090
		source "$s" >/dev/null 2>&1
		set -eu
		command -v "$1" >/dev/null 2>&1 || die "$1 이(가) $s 환경에 없습니다."
		"$@"
	)
}

# ---------------------------------------------------------------------------
# XSA / 디바이스 트리 / Kconfig
# ---------------------------------------------------------------------------
xsa_unpack() {   # xsa_unpack <xsa> <디렉터리> — XSA는 zip이다
	rm -rf "$2"
	mkdir -p "$2"
	unzip -q -o "$1" -d "$2" || die "XSA를 풀 수 없습니다: $1"
}

find_one() {   # find_one <디렉터리> <이름 패턴> — 정확히 하나만 있어야 한다
	local r=()
	mapfile -t r < <(find "$1" -type f -name "$2" | LC_ALL=C sort)
	((${#r[@]} == 1)) || return 1
	printf '%s' "${r[0]}"
}

# DTG(xsct) 실행: dtg_run <xsa> <device-tree-xlnx> <출력> <프로세서> <보드|-> <오버레이 0|1> <펌웨어 이름|->
dtg_run() {
	xrun xsct "$TOP/scripts/dtg.tcl" "$@"
}

dt_cpp() {   # dt_cpp <출력> <입력> <include 디렉터리...>
	local out=$1 in=$2 d inc=()
	shift 2
	for d; do inc+=(-I "$d"); done
	"${HOSTCC:-gcc}" -E -nostdinc -undef -D__DTS__ -x assembler-with-cpp "${inc[@]}" -o "$out" "$in"
}

kconfig_merge() {   # kconfig_merge <소스> <obj> <조각...> — obj/.config 위에 조각을 얹는다
	local src=$1 obj=$2
	shift 2
	(cd "$src" && bash scripts/kconfig/merge_config.sh -m -O "$obj" "$obj/.config" "$@")
}

# kconfig_check <strict 0|1> <.config> <조각...> — 조각에 적은 값이 최종 설정에 들어갔는지 확인
kconfig_check() {
	local strict=$1 cfg=$2 f fname line sym val cur bad=0
	shift 2
	for f; do
		fname=${f##*/}
		while IFS= read -r line || [[ -n $line ]]; do
			if [[ $line =~ ^(CONFIG_[A-Za-z0-9_]+)=(.*)$ ]]; then
				sym=${BASH_REMATCH[1]} val=${BASH_REMATCH[2]}
				grep -qxF "$sym=$val" "$cfg" && continue
			elif [[ $line =~ ^#\ (CONFIG_[A-Za-z0-9_]+)\ is\ not\ set ]]; then
				sym=${BASH_REMATCH[1]} val=n
				grep -qE "^$sym=" "$cfg" || continue
			else
				continue
			fi
			cur=$(grep -E "^(# )?${sym}[= ]" "$cfg" || true)
			warn "$fname: $sym=$val 이(가) 반영되지 않았습니다 (최종: ${cur:-없음}). 의존 옵션을 확인하세요."
			bad=1
		done <"$f"
	done
	((strict == 0 || bad == 0)) || die "필수 설정이 반영되지 않았습니다."
	return 0
}
