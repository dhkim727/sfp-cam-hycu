# hw/

Vivado에서 만든 XSA를 여기에 둔다.

- Vivado: File > Export > Export Hardware > **Include bitstream** 선택
- 파일 이름은 자유. `system.xsa`가 있으면 그것을, 없으면 이 폴더의 유일한 `.xsa`를 자동으로 쓴다.
  여러 개면 `config.env`의 `XSA=` 또는 `./build.sh --xsa <파일>`로 고른다.
- XSA가 바뀌면 `./build.sh`가 hw → dt → uboot → image만 다시 만든다 (커널·rootfs는 재사용).
