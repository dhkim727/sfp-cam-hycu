# Zynq-7015 Linux 구성 계획

> 시스템 1 수신부(Zynq-7015 보드)에 Linux를 올리기 위한 빌드·부팅 계획
> 기준 툴: Vivado / Vitis 2025.2 · 빌드 호스트: Ubuntu 22.04.5 LTS · 작성: 2026.10
> 짝 문서: `zcu104_linux_plan.md` (송신부)

---

## 1. 목표와 범위

- XSA 하나를 입력으로 부트 산출물(BOOT.BIN, U-Boot, DTB)을 다시 만드는 빌드 스크립트를 만든다.
- 부팅 체인: **U-Boot SPL(FSBL 대체) → U-Boot → Linux (linux-xlnx)**
- 루트 파일 시스템: **Debian 13 (trixie) armhf** 기본, 필요하면 Ubuntu 24.04 (noble) armhf로 전환한다.
- Linux는 관리·디버그용이다. 광 → PCIe 데이터 경로(Aurora → frame_gate → FIFO → XDMA)는 PL만으로 동작하므로 Linux가 있든 없든 바뀌지 않는다.

---

## 2. 버전 고정

| 구성 요소 | 버전 · 태그 | 비고 |
|---|---|---|
| 하드웨어 설계 | Vivado 2025.2 → XSA | |
| DT 생성 | device-tree-xlnx `xilinx_v2025.2` + xsct (DTG) | SDTGen + lopper로 교체할 수 있게 단계 분리 |
| U-Boot | u-boot-xlnx `xilinx-v2025.2` | "2025.2"는 mainline 버전이 아니라 AMD 릴리스 태그 |
| Linux | linux-xlnx `xilinx-v2025.2` | 6.12 LTS 계열 (2025.1에서 6.12로 올라감) |
| 툴체인 | `gcc-arm-linux-gnueabihf` (Ubuntu 22.04 패키지) | 커널·U-Boot 빌드 전용 |
| rootfs | Debian 13 trixie armhf | 선택: Ubuntu 24.04 noble armhf |

- 태그명은 저장소마다 `xilinx-v` / `xilinx_v` 표기가 다르다. 스크립트가 `git ls-remote --tags`로 존재를 확인한 뒤 체크아웃한다.
- 타깃용 사용자 프로그램은 타깃에서 직접 빌드하거나 qemu chroot 안에서 빌드하는 것이 가장 안전하다. 호스트 크로스 컴파일 시에는 타깃(Debian 13)보다 오래된 glibc로 빌드해야 호환된다.

---

## 3. 빌드 구조 — 3개 도메인

XSA가 바뀌면 부트 쪽만 다시 만들고, 커널과 rootfs는 각자 캐시를 재사용한다.

```
[XSA 도메인]     system.xsa → hw → dt → uboot → BOOT.BIN, u-boot.img
                                    └→ system.dtb
[커널 도메인]    linux-xlnx → kernel → zImage, modules.tar      (필요할 때만)
[rootfs 도메인]  mmdebstrap → rootfs → rootfs.tar               (캐시 재사용)
                                       │
                         모두 image 단계로 → boot.scr, sdcard.img
```

---

## 4. 단계 정의

| 단계 | 입력 | 출력 | 다시 도는 조건 |
|---|---|---|---|
| fetch | 태그 3종 | `src/` 소스 트리 | 최초 1회, 태그 변경 |
| hw | `hw/system.xsa` | ps7_init_gpl.c/h, system.bit, *.hwh | XSA 해시 변경 |
| dt | hw 출력, `board/board.dtsi` | Linux용 system.dtb, U-Boot용 DTS | hw 또는 board.dtsi 변경 |
| uboot | dt·hw 출력, `board/uboot.config` | BOOT.BIN(= spl/boot.bin), u-boot.img | dt·hw·조각 설정 변경 |
| kernel | linux-xlnx, `board/kernel.config` | zImage, modules.tar | 소스·설정 해시 변경 또는 산출물 없음 |
| rootfs | `config.env`, `board/overlay/` | rootfs.tar | 배포판 설정·overlay 변경 |
| image | 위 산출물, `board/boot.cmd` | boot.scr, sdcard.img | 위 중 하나라도 변경 |

- 변경 감지는 파일 수정 시각이 아니라 **입력의 sha256**을 `build/<단계>/.hash`에 저장해 비교한다.
- XSA가 바뀌어도 실제로 다시 도는 것은 hw → dt → uboot → image 구간뿐이라 수 분 안에 끝난다.
- 정말 처음부터 다시 만들 때는 `--clean`을 쓴다.

---

## 5. 단계별 상세

### 5.1 fetch

- u-boot-xlnx, linux-xlnx, device-tree-xlnx를 `src/` 아래에 태그 고정으로 클론한다.
- `git describe --tags`로 실제 체크아웃된 태그를 로그에 남긴다.

### 5.2 hw — XSA 해제

- XSA는 zip 파일이다. Zynq-7000용 XSA에는 ps7_init_gpl.c/h와 비트스트림이 들어 있어 `unzip`만으로 꺼낼 수 있다.
- 비트스트림 이름은 `system.bit`로 통일한다. boot.cmd가 고정 이름을 쓰도록 하기 위해서다.

### 5.3 dt — 디바이스 트리

- **1차: DTG** (xsct + device-tree-xlnx). Vitis 2025.2 설치본에 xsct가 있는지 먼저 확인한다.
- **대안: SDTGen** (Vitis 2025.2 포함)으로 System Device Tree를 만든 뒤 lopper로 Linux DT를 뽑는다. AMD는 DTG를 향후 폐기할 예정이므로, dt 단계를 함수 하나로 분리해 `DT_GEN=dtg|sdtgen`으로 바꿀 수 있게 둔다.
- 생성물(system-top.dts, pcw.dtsi, pl.dtsi 등)은 손대지 않는다. 보드 고유 정보는 `board/board.dtsi`에서 덮어쓴다.
  - 이더넷 PHY 주소, phy-mode
  - SD 카드 감지·쓰기 보호 처리
  - QSPI 플래시 종류와 파티션
  - LED·버튼 GPIO
  - `chosen` (bootargs, stdout-path)
- 생성 DTS가 `<dt-bindings/...>`를 include하면, linux-xlnx의 `include/` 경로로 cpp 전처리한 뒤 dtc로 컴파일한다.
- 같은 DTS를 U-Boot에도 넘긴다. PL 노드는 U-Boot 동작에 영향을 주지 않는다.

### 5.4 uboot — SPL + U-Boot

- `xilinx_zynq_virt_defconfig`에 `board/uboot.config` 조각을 얹는다.
- `CONFIG_XILINX_PS_INIT_FILE`에 hw 단계에서 꺼낸 ps7_init_gpl.c 경로를 지정한다. U-Boot가 이 파일을 함께 빌드해 SPL이 DDR·클럭·MIO를 초기화한다. Vitis로 FSBL을 따로 빌드할 필요가 없다.
- 생성 DTS를 U-Boot 트리에 보드 DTS로 넣고 `DEVICE_TREE`(또는 `CONFIG_DEFAULT_DEVICE_TREE`)로 지정한다.
- 산출물: `spl/boot.bin` → `BOOT.BIN`, `u-boot.img`
- 첫 빌드에서 확인할 것
  - 이 버전에서 `CONFIG_OF_UPSTREAM`이 켜져 있는지 (켜져 있으면 로컬 DTS를 쓰는 방법 확인)
  - SPL이 쓰는 UART·SD·QSPI 노드에 `bootph-all` 태그가 필요한지
- PL 클럭(FCLK0~3) 설정도 ps7_init에 들어 있다. PL 클럭만 바뀌어도 SPL을 다시 빌드해야 하므로, XSA 변경 시 uboot 단계를 항상 다시 도는 규칙이 맞다.

### 5.5 kernel

- `xilinx_zynq_defconfig`에 `board/kernel.config` 조각을 `scripts/kconfig/merge_config.sh`로 합친다.
- systemd 필수 옵션 조각:

  ```
  CONFIG_DEVTMPFS=y
  CONFIG_DEVTMPFS_MOUNT=y
  CONFIG_CGROUPS=y
  CONFIG_FHANDLE=y
  CONFIG_INOTIFY_USER=y
  CONFIG_SIGNALFD=y
  CONFIG_TIMERFD=y
  CONFIG_EPOLL=y
  CONFIG_TMPFS_POSIX_ACL=y
  CONFIG_AUTOFS_FS=y
  ```

- 산출물: `zImage`, `modules.tar` (`make modules_install INSTALL_MOD_PATH=<임시 디렉터리>` 후 묶음)
- XSA와 무관하므로 소스·설정 해시가 같으면 재사용한다.

### 5.6 rootfs

- `mmdebstrap`로 armhf rootfs를 만든다. 호스트에 `qemu-user-static`과 `binfmt-support`가 있으면 2단계 설치까지 root 권한 없이 자동으로 끝난다.

  ```
  mmdebstrap --architectures=armhf --variant=minbase \
    --include=systemd-sysv,udev,systemd-resolved,openssh-server,iproute2,sudo,ca-certificates \
    trixie rootfs.tar http://deb.debian.org/debian
  ```

- 빌드 호스트(Ubuntu 22.04)의 `debian-archive-keyring`이 오래돼 trixie 서명 키가 없을 수 있다. 실패하면 Debian의 최신 `debian-archive-keyring`을 받아 `--keyring`으로 지정한다.
- 후처리 (`--customize-hook` 또는 `board/overlay/`)
  - hostname, `/etc/fstab` (root = `/dev/mmcblk0p2`)
  - 시리얼 콘솔: 커널 인자 `console=ttyPS0,115200`이 있으면 systemd가 serial-getty를 자동으로 띄운다
  - 사용자 계정 + sudo, SSH 활성화
  - 네트워크: systemd-networkd `.network` 파일로 eth0 DHCP
  - apt sources, 시간대, 로캘
- **Ubuntu 24.04로 전환**: suite를 `noble`, 미러를 `http://ports.ubuntu.com/ubuntu-ports`, 컴포넌트를 `main,universe`로만 바꾼다. 커널 6.12와 두 배포판 모두 호환된다.
- 커널 모듈은 image 단계에서 `modules.tar`를 rootfs의 `/lib/modules`에 푼다.

### 5.7 image

- boot.cmd (비트스트림 → 커널 → DTB 순):

  ```
  load mmc 0:1 ${loadaddr} system.bit && fpga loadb 0 ${loadaddr} ${filesize}
  load mmc 0:1 ${kernel_addr_r} zImage
  load mmc 0:1 ${fdt_addr_r} system.dtb
  setenv bootargs console=ttyPS0,115200 root=/dev/mmcblk0p2 rw rootwait
  bootz ${kernel_addr_r} - ${fdt_addr_r}
  ```

  `mkimage -A arm -T script -C none -d boot.cmd boot.scr`로 변환한다.

- SD 카드 구성

  | 파티션 | 형식 | 크기 | 내용 |
  |---|---|---|---|
  | p1 | FAT32 | 256 MiB | BOOT.BIN, u-boot.img, boot.scr, zImage, system.dtb, system.bit |
  | p2 | ext4 | 나머지 | rootfs + `/lib/modules` |

- 이미지는 root 권한 없이 만든다. FAT은 `mkfs.vfat` + `mcopy`(mtools), ext4는 `mke2fs -d <rootfs 디렉터리>`로 만든 뒤 `sfdisk`로 파티션 테이블과 합친다.
- 이후 단계: BOOT.BIN과 u-boot.img를 QSPI에 넣고 커널·rootfs만 SD에 두는 구성으로 옮긴다.

---

## 6. 비트스트림 로드 정책과 PCIe 타이밍

- SPL에서 비트스트림을 올리는 방식은 SD 모드에서만 되고, QSPI 모드에서는 U-Boot나 Linux 단계에서 올려야 한다. SPL FIT 경로로 Zynq-7000에 비트스트림을 올리다 실패해 별도 패치가 필요했던 사례도 있다.
- 그래서 SD·QSPI 어느 쪽이든 같은 방식으로 동작하는 **U-Boot의 `fpga loadb`로 통일**한다. XSA 안의 .bit를 변환 없이 그대로 쓸 수 있다.
- 대신 PL이 올라오는 시점이 FSBL 방식보다 늦다. Z7015는 PCIe 엔드포인트라, 호스트가 먼저 버스를 열거하면 장치를 못 볼 수 있다.
  - 개발 중: 호스트에서 `echo 1 | sudo tee /sys/bus/pci/rescan`
  - UT3G(USB4) 핫플러그 환경: 링크가 올라오는 순간 인식되므로 문제없음
  - 계속 문제가 되면: uboot 단계를 **FSBL + bootgen** 경로로 바꿔 비트스트림을 BOOT.BIN에 넣는다. 단계가 분리돼 있어 uboot 단계만 교체하면 된다.

---

## 7. 디렉터리 구조

```
z7015-linux/
├── build.sh            # ./build.sh [all|hw|dt|uboot|kernel|rootfs|image] [--clean]
├── config.env          # 태그, 툴체인, 보드명, 배포판
├── hw/
│   └── system.xsa
├── board/              # 손으로 관리 (Git)
│   ├── board.dtsi
│   ├── uboot.config    # defconfig 조각
│   ├── kernel.config   # systemd 등 조각
│   ├── boot.cmd
│   └── overlay/        # rootfs에 덮어쓸 파일
├── src/                # u-boot-xlnx, linux-xlnx, device-tree-xlnx (태그 고정)
├── build/<단계>/       # 작업 디렉터리 + .hash
└── out/                # BOOT.BIN, u-boot.img, boot.scr, zImage, system.dtb,
                        # system.bit, rootfs.tar, sdcard.img
```

---

## 8. build.sh 인터페이스

### 8.1 사용법

```
./build.sh all            # 필요한 단계만 자동 판단해 실행
./build.sh uboot          # 특정 단계만 (앞 단계가 오래됐으면 같이 실행)
./build.sh all --clean    # 캐시 무시하고 전부 다시
```

### 8.2 config.env 예시

```
UBOOT_TAG=xilinx-v2025.2
LINUX_TAG=xilinx-v2025.2
DTG_TAG=xilinx_v2025.2
DT_GEN=dtg                       # dtg | sdtgen
CROSS_COMPILE=arm-linux-gnueabihf-
DISTRO=debian                    # debian | ubuntu
SUITE=trixie                     # trixie | noble
MIRROR=http://deb.debian.org/debian
SD_BOOT_MB=256
```

### 8.3 재빌드 규칙

| 바뀐 것 | 다시 도는 단계 |
|---|---|
| XSA | hw → dt → uboot → image |
| board.dtsi | dt → uboot → image |
| uboot.config | uboot → image |
| 커널 소스·kernel.config | kernel → image |
| 배포판 설정·overlay | rootfs → image |
| boot.cmd | image |

---

## 9. 빌드 호스트 준비

- Ubuntu 22.04.5 LTS (Vivado 2025.2와 같은 호스트)
- 패키지:

  ```
  sudo apt install git build-essential bc bison flex libssl-dev libgnutls28-dev \
    python3 python3-dev python3-setuptools swig device-tree-compiler u-boot-tools \
    gcc-arm-linux-gnueabihf mmdebstrap qemu-user-static binfmt-support \
    dosfstools mtools e2fsprogs fdisk xz-utils unzip
  ```

- Vivado / Vitis 2025.2의 `settings64.sh`를 불러 xsct(또는 sdtgen)가 PATH에 잡히게 한다.

---

## 10. 마일스톤

| 단계 | 내용 | 통과 기준 |
|---|---|---|
| M1 | XSA → SPL + U-Boot | UART에 U-Boot 프롬프트 |
| M2 | DT + 커널 | 커널 부팅, 메모리·SD·이더넷 인식 |
| M3 | Debian rootfs | 시리얼·SSH 로그인, apt 동작 |
| M4 | 비트스트림 로드 | `fpga loadb` 후 호스트 `lspci`에 장치 표시 |
| M5 | 자동화 검증 | PL만 바꾼 XSA로 재빌드 → 커널·rootfs 재사용 확인 → 부팅 성공 |

- M1은 board.dtsi 없이 ps7_init만으로도 갈 수 있다. UART 프롬프트부터 띄워 DDR·클럭 설정이 맞는지 확인하는 것이 가장 빠른 길이다.

---

## 11. 리스크와 대응

| 리스크 | 대응 |
|---|---|
| DTG 폐기 예정 | dt 단계를 함수로 분리, SDTGen + lopper로 교체 가능하게 유지 |
| U-Boot의 OF_UPSTREAM · bootph 태그 | 첫 빌드에서 확인, 필요한 속성은 board.dtsi에 추가 |
| PCIe 열거 타이밍 | rescan으로 우회, 계속 문제면 FSBL + bootgen 경로로 교체 |
| 보드 정보 부족 (PHY, SD 감지 등) | 보드 회로도와 벤더 BSP의 DTS를 참고해 board.dtsi 작성 |
| 호스트 키링이 trixie 미지원 | 최신 debian-archive-keyring을 `--keyring`으로 지정 |
| armhf 장기 지원 | Debian LTS 기간에는 지원 아키텍처가 줄어들 수 있음 → 정규 지원 종료(2028.08) 전에 재검토 |

---

## 12. 참고 자료

- u-boot-xlnx: https://github.com/Xilinx/u-boot-xlnx
- linux-xlnx: https://github.com/Xilinx/linux-xlnx
- device-tree-xlnx: https://github.com/Xilinx/device-tree-xlnx
- Build Device Tree Blob (AMD 위키): https://xilinx-wiki.atlassian.net/wiki/spaces/A/pages/18842279
- U-Boot Secondary Program Loader (AMD 위키): https://xilinx-wiki.atlassian.net/wiki/spaces/A/pages/18842574
- 2025.1 Release Notes for Open Source Components: https://xilinx-wiki.atlassian.net/wiki/spaces/A/pages/3277651969
- Generating a System Device Tree Using SDTGen (UG1647): https://docs.amd.com/r/en-US/ug1647-porting-embeddedsw-components/Generating-a-System-Device-Tree-Using-SDTGen
- Debian trixie 릴리스 정보: https://www.debian.org/releases/trixie/
